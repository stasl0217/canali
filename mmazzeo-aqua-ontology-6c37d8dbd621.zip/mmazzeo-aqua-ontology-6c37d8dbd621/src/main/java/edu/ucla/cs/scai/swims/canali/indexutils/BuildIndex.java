/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.indexutils;

import edu.ucla.cs.scai.swims.canali.index.tokens.AttributeToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.CategoryToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.EntityToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.IndexedToken;
import static edu.ucla.cs.scai.swims.canali.index.tokens.LiteralToken.*;
import edu.ucla.cs.scai.swims.canali.index.tokens.OntologyElementToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.FSDirectory;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 *
 * This class contains the function for creating a Lucene directory, that can be
 * used by the AQUA system, starting from an ontology stored in the following
 * text files (the format for each file is specified in the method using it)
 *
 * triples: contain the triples subject, attribute, value
 *
 * attribute_labels: each row contains and attribute URI and a label - the same
 * attribute URI can appear on multiple rows (multiple labels)
 *
 * category_labels: each row contains a category URI and a label - the same
 * category URI can appear on multiple rows (multiple labels)
 *
 * category_parents each row contains a category URI and the URI of one of its
 * category parents
 *
 * entity_labels: each row contains an entity URI and a label - the same entity
 * URI can appear on multiple rows (multiple labels)
 *
 * entity_categories: each row contains an entity URI and the URI of one of its
 * categories
 *
 * basic_types_literal_types: each row contains a basic type URI and either
 * Double, Date, String, or Boolean
 *
 * additional_attribute_labels: other attribute labels
 *
 * additional_category_labels: other category labels
 *
 * additional_entity_labels: other category labels
 */
public class BuildIndex {

    String basePathInput, basePathOutput;
    int[] entityTriplesSubjects;
    short[] entityTriplesAttributes;
    int[] entityTriplesValues;
    //ArrayList<int[]> entityTriples = new ArrayList<>();
    //HashMap<String, ArrayList<int[]>> literalTriples = new HashMap<>();
    HashMap<String, int[]> literalTriplesSubjects = new HashMap<>();
    HashMap<String, short[]> literalTriplesAttributes = new HashMap<>();
    HashSet<String> literalTypes = new HashSet<>();
    HashMap<String, Integer> entityIdFromUriWithPrefix = new HashMap<>();
    HashMap<String, Short> attributeIdFromUri = new HashMap<>();
    HashMap<String, Integer> categoryIdFromUri = new HashMap<>();
    String[] entityUriWithPrefix;
    String[] attributeUri;
    String[] categoryUri;
    HashSet<String>[] attributeLabels;
    HashSet<String>[] entityLabels;
    HashSet<String>[] categoryLabels;
    HashSet<Integer>[] entityCategories;
    HashMap<String, String> basicTypesMapping = new HashMap<>();
    HashSet<Integer>[] categoryParents;
    HashSet<Integer>[] categoryAncestors;
    HashSet<Integer>[] categoryChildren;
    HashSet<Integer>[] categoryDescendants;
    HashSet<Short>[] entityOutAttributes;
    HashSet<Short>[] entityInAttributes;
    HashSet<Short>[] categoryOutAttributes;
    HashSet<Short>[] categoryInAttributes;
    HashSet<Short>[] attributeInAttributes;
    HashSet<Short>[] attributeOutAttributes;
    int[] attributeCount;
    boolean[] attributeHasLiteralRange;
    HashMap<String, HashSet<Short>> literalTypesInAttributes = new HashMap<>();
    int iEntityTriples = 0;
    HashMap<String, Integer> iLiteralTriples = new HashMap<>();
    public final static String THING = "http://www.w3.org/2002/07/owl#Thing";
    int thingId;
    boolean printFiles = false;
    int minAttributeLength = 2;

    static final HashMap<String, String> uriToPrefix = new HashMap<>();
    static final HashMap<String, String> prefixToUri = new HashMap<>();

    static final boolean DROP_UNLABELED_ENTITIES = false;

    static {
        uriToPrefix.put("http://musicbrainz.org/area/", "1:");
        uriToPrefix.put("http://musicbrainz.org/artist/", "2:");
        uriToPrefix.put("http://musicbrainz.org/artist/", "3:");
        uriToPrefix.put("http://musicbrainz.org/record/", "4:");
        uriToPrefix.put("http://musicbrainz.org/place/", "5:");
        uriToPrefix.put("http://musicbrainz.org/recording/", "6:");
        uriToPrefix.put("http://musicbrainz.org/place/", "7:");
        uriToPrefix.put("http://musicbrainz.org/place/", "8:");
        uriToPrefix.put("http://musicbrainz.org/tag/", "9:");
        uriToPrefix.put("http://musicbrainz.org/track/", "a:");
        uriToPrefix.put("http://musicbrainz.org/work/", "b:");
        for (Map.Entry<String, String> e : uriToPrefix.entrySet()) {
            prefixToUri.put(e.getValue(), e.getKey());
        }
    }

    public BuildIndex(String basePathInput, String basePathOutput) {
        if (!basePathInput.endsWith(File.separator)) {
            basePathInput += File.separator;
        }
        this.basePathInput = basePathInput;
        if (!basePathOutput.endsWith(File.separator)) {
            basePathOutput += File.separator;
        }
        this.basePathOutput = basePathOutput;
        literalTypesInAttributes.put(DOUBLE, new HashSet<Short>());
        literalTypesInAttributes.put(STRING, new HashSet<Short>());
        literalTypesInAttributes.put(DATE, new HashSet<Short>());
        literalTypesInAttributes.put(BOOLEAN, new HashSet<Short>());
        //literalTriples.put(STRING, new ArrayList<int[]>());
        //literalTriples.put(BOOLEAN, new ArrayList<int[]>());
        //literalTriples.put(DOUBLE, new ArrayList<int[]>());
        //literalTriples.put(DATE, new ArrayList<int[]>());
        literalTypes.add(STRING);
        literalTypes.add(BOOLEAN);
        literalTypes.add(DOUBLE);
        literalTypes.add(DATE);
        for (String type : literalTypes) {
            iLiteralTriples.put(type, 0);
        }
    }

    private Integer getEntityIdFromUri(String uri) {
        for (String p : uriToPrefix.keySet()) {
            if (uri.startsWith(p)) {
                uri = uri.replace(p, uriToPrefix.get(p));
                break;
            }
        }
        return entityIdFromUriWithPrefix.get(uri);
    }

    private String getEntityCompleteUri(String uri) {
        for (String p : prefixToUri.keySet()) {
            if (uri.startsWith(p)) {
                return uri.replace(p, prefixToUri.get(p));
            }
        }
        return uri;
    }

    private void putEntityIdFromUri(String uri, int id) {
        for (String p : uriToPrefix.keySet()) {
            if (uri.startsWith(p)) {
                uri = uri.replace(p, uriToPrefix.get(p));
                break;
            }
        }
        entityIdFromUriWithPrefix.put(uri, id);
    }

    private void updateTriples(String subj, String attr, String entityVal, String literalType) {
        Integer idSbj = getEntityIdFromUri(subj);//entityIdFromUri.get(subj);
        Short idAttr = attributeIdFromUri.get(attr);
        if (entityVal != null) {
            Integer idVal = getEntityIdFromUri(entityVal);//entityIdFromUri.get(entityVal);
            entityTriplesSubjects[iEntityTriples] = idSbj;
            entityTriplesAttributes[iEntityTriples] = idAttr;
            entityTriplesValues[iEntityTriples] = idVal;
            iEntityTriples++;
            //now, create the inverted triple
            Short idInvAttr = attributeIdFromUri.get(attr + "Inv");
            entityTriplesSubjects[iEntityTriples] = idVal;
            entityTriplesAttributes[iEntityTriples] = idInvAttr;
            entityTriplesValues[iEntityTriples] = idSbj;
            iEntityTriples++;
        } else {
            int pos = iLiteralTriples.get(literalType);
            literalTriplesSubjects.get(literalType)[pos] = idSbj;
            literalTriplesAttributes.get(literalType)[pos] = idAttr;
            iLiteralTriples.put(literalType, pos + 1);
        }
    }
    /*
     The file triples must contain one row per triple <subject, attribute, value>, with the form
     <uri_subject> <uri_attribute> <uri_value>
     or
     <uri_subject> <uri_attribute> "value"
     or
     <uri_subject> <uri_attribute> "value"<basic_type>
     e.g.
     <http://dbpedia.org/resource/01_Communique> <http://dbpedia.org/ontology/industry> <http://dbpedia.org/resource/Software>
     or
     <http://dbpedia.org/resource/Kikuzo_Kisaka> <http://xmlns.com/foaf/0.1/name> "Kisaka, Kikuzo"@en
     or
     <http://dbpedia.org/resource/Kiko_Casilla> <http://dbpedia.org/ontology/alias> "Casilla, Francisco"
     or
     <http://dbpedia.org/resource/Kiki_S%C3%B8rum> <http://dbpedia.org/ontology/birthDate> "1939-01-16"^^<http://www.w3.org/2001/XMLSchema#date>
     Triples whose value is an entity are loaded into a list of of arrays of integers containing 3 elements: subject id, attribute id, value id. Ids are assigned as new entities are processed.
     Triples whose value is a literal are loaded into one of 4 lists of arrays of integers, depending on the type of literal, containing 2 elements: subject id, attribute id.
     Entities and attributes that are not found in this file will be ignored in the following.
     */

    private void loadTriples() throws Exception {
        HashMap<String, Integer> attributeFrequency = new HashMap<>();
        HashSet<String> shortAttributes = new HashSet<>();
        if (minAttributeLength > 1) {
            System.out.println("Finding attributes to be ignored because they have lenght less than " + minAttributeLength);
            try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "attribute_labels"))) {
                String l = in.readLine();
                while (l != null) {
                    if (l.length() > 0) {
                        StringTokenizer st = new StringTokenizer(l, "\t<>");
                        String uri = st.nextToken().trim();
                        if (uri.startsWith("http")) {
                            String label = st.hasMoreTokens() ? st.nextToken().trim() : "";
                            if (label.length() < minAttributeLength && !shortAttributes.contains(uri)) {
                                shortAttributes.add(uri);
                                System.out.println("Attribute " + uri + " will be ignored, having label " + label);
                                attributeFrequency.put(uri, 0);
                            }
                        }
                    }
                    l = in.readLine();
                }
            }
            System.out.println(shortAttributes.size() + " attributes will be ignored, having lenght less than " + minAttributeLength);
        }
        int maxNumberOfAttributes = 5 * Short.MAX_VALUE / 8; //assuming that invertible attributes are 3/2 of non-invertible attributes
        System.out.println("Finding the the " + maxNumberOfAttributes + " most frequent attributes of the attributes whose label has at least two characters");
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "triples"))) {
            String l = in.readLine();
            int n = 0;
            while (l != null && l.length() > 0) {
                StringTokenizer st = new StringTokenizer(l, "<> ");
                String subject = st.nextToken();
                String attribute = st.nextToken();
                String value = st.nextToken();
                if (subject.startsWith("http") && attribute.startsWith("http") && !shortAttributes.contains(attribute)) {
                    if (value.startsWith("http") || value.startsWith("ftp:")) { //it is an entity
                        Integer c = attributeFrequency.get(attribute);
                        if (c == null) {
                            attributeFrequency.put(attribute, 1);
                        } else {
                            attributeFrequency.put(attribute, 1 + c);
                        }
                    } else { //it is a literal
                        if (value.endsWith("^^")) { //it is a basic type
                            String type = StringEscapeUtils.unescapeJava(st.nextToken());
                            String literalType = basicTypesMapping.get(type);
                            if (literalType != null) {
                                Integer c = attributeFrequency.get(attribute);
                                if (c == null) {
                                    attributeFrequency.put(attribute, 1);
                                } else {
                                    attributeFrequency.put(attribute, 1 + c);
                                }
                            }
                        } else {
                            if (value.startsWith("\"")) { //it is a String
                                Integer c = attributeFrequency.get(attribute);
                                if (c == null) {
                                    attributeFrequency.put(attribute, 1);
                                } else {
                                    attributeFrequency.put(attribute, 1 + c);
                                }
                            }
                        }
                    }
                    n++;
                    if (n % 1000000 == 0) {
                        System.out.println("Scanned " + (n / 1000000) + "M triples");
                    }
                } else {
                    //System.out.println("Invalid triple: " + l);
                }
                l = in.readLine();
            }
        }
        shortAttributes = null;
        System.gc();
        ArrayList<Map.Entry<String, Integer>> f = new ArrayList<>(attributeFrequency.entrySet());
        Collections.sort(f, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return Integer.compare(o2.getValue(), o1.getValue());
            }
        });
        int minFreq = 1;
        if (f.size() > maxNumberOfAttributes) {
            minFreq = f.get(maxNumberOfAttributes - 1).getValue();
            if (f.get(maxNumberOfAttributes).equals(f.get(maxNumberOfAttributes - 1))) {
                minFreq++;
            }
        }
        for (Map.Entry<String, Integer> e : f) {
            System.out.println(e.getKey() + "\t" + e.getValue());
        }
        System.out.println("Keeping attributes with at least " + minFreq + " occurrences");
        HashSet<String> acceptedAttributes = new HashSet<>();
        for (Map.Entry<String, Integer> e : attributeFrequency.entrySet()) {
            if (e.getValue() >= minFreq) {
                acceptedAttributes.add(e.getKey());
            }
        }
        System.out.println(acceptedAttributes.size() + " attributes kept over " + f.size());
        f = null;
        attributeFrequency = null;
        System.gc();
        System.out.println("Mapping entities and attribute URIs to ids");
        int nEntityTriples = 0;
        HashMap<String, Integer> nLiteralTriples = new HashMap<>();
        for (String type : literalTypes) {
            nLiteralTriples.put(type, 0);
        }
        HashSet<String> unrecognizedBasicTypes = new HashSet<>();
        //count entity-valued and literal-valued triples
        //and
        //create the association between uris and ids for entities        
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "triples"))) {
            String l = in.readLine();
            int n = 0;
            while (l != null && l.length() > 0) {
                StringTokenizer st = new StringTokenizer(l, "<> ");
                String subject = st.nextToken();
                String attribute = st.nextToken();
                if (!acceptedAttributes.contains(attribute)) {
                    l = in.readLine();
                    continue;
                }
                String value = st.nextToken();
                if (subject.startsWith("http") && attribute.startsWith("http")) {
                    Integer idSbj = getEntityIdFromUri(subject); //entityIdFromUri.get(subject);
                    if (idSbj == null) {
                        idSbj = entityIdFromUriWithPrefix.size() + 1;//entityIdFromUri.size() + 1;
                        putEntityIdFromUri(subject, idSbj); //entityIdFromUri.put(subject, idSbj);
                    }
                    Short idAttr = attributeIdFromUri.get(attribute);
                    if (idAttr == null) {
                        idAttr = (short) (attributeIdFromUri.size() + 1);
                        attributeIdFromUri.put(attribute, idAttr);
                    }
                    if (value.startsWith("http") || value.startsWith("ftp:")) { //it is an entity
                        Integer idVal = getEntityIdFromUri(value); //entityIdFromUri.get(value);
                        if (idVal == null) {
                            idVal = entityIdFromUriWithPrefix.size() + 1;//entityIdFromUri.size() + 1;
                            putEntityIdFromUri(value, idVal);//entityIdFromUri.put(value, idVal);
                        }
                        Short idInvAttr = attributeIdFromUri.get(attribute + "Inv");
                        if (idInvAttr == null) {
                            idInvAttr = (short) (attributeIdFromUri.size() + 1);
                            attributeIdFromUri.put(attribute + "Inv", idInvAttr);
                        }
                        nEntityTriples += 2;
                    } else { //it is a literal
                        if (value.endsWith("^^")) { //it is a basic type
                            String type = StringEscapeUtils.unescapeJava(st.nextToken());
                            String literalType = basicTypesMapping.get(type);
                            if (literalType != null) {
                                nLiteralTriples.put(literalType, nLiteralTriples.get(literalType) + 1);
                            } else {
                                if (!unrecognizedBasicTypes.contains(type)) {
                                    System.out.println("Unrecognized type: " + type);
                                    System.out.println("in line: " + l);
                                    unrecognizedBasicTypes.add(type);
                                }
                            }
                        } else {
                            if (value.startsWith("\"")) { //it is a String
                                nLiteralTriples.put(STRING, nLiteralTriples.get(STRING) + 1);
                            }
                        }
                    }
                    n++;
                    if (n % 1000000 == 0) {
                        System.out.println("Loaded " + (n / 1000000) + "M triples");
                    }
                } else {
                    System.out.println("Invalid triple: " + l);
                }
                l = in.readLine();
            }
        }
        System.out.println("Number of triples with entity value: " + nEntityTriples);
        for (String type : literalTypes) {
            System.out.println("Number of triples with " + type + " value: " + nLiteralTriples.get(type));
        }
        entityTriplesSubjects = new int[nEntityTriples];
        entityTriplesAttributes = new short[nEntityTriples];
        entityTriplesValues = new int[nEntityTriples];
        for (String type : literalTypes) {
            literalTriplesSubjects.put(type, new int[nLiteralTriples.get(type)]);
            literalTriplesAttributes.put(type, new short[nLiteralTriples.get(type)]);
        }
        //load the triples into the arrays creaded above
        System.out.println("Loading triples");
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "triples"))) {
            String l = in.readLine();
            int n = 0;
            while (l != null && l.length() > 0) {
                StringTokenizer st = new StringTokenizer(l, "<> ");
                String sbj = st.nextToken();
                String attr = st.nextToken();
                if (!acceptedAttributes.contains(attr)) {
                    l = in.readLine();
                    continue;
                }
                String val = st.nextToken();
                if (sbj.startsWith("http") && attr.startsWith("http")) {
                    if (val.startsWith("http") || val.startsWith("ftp:")) { //it is an entity
                        updateTriples(sbj, attr, val, null);
                    } else { //it is a literal
                        if (val.endsWith("^^")) { //it is a basic type
                            String type = StringEscapeUtils.unescapeJava(st.nextToken());
                            String literalType = basicTypesMapping.get(type);
                            if (literalType != null) {
                                updateTriples(sbj, attr, null, literalType);
                            } else {
                                if (!unrecognizedBasicTypes.contains(type)) {
                                    System.out.println("Unrecognized type: " + type);
                                    System.out.println("in line: " + l);
                                    unrecognizedBasicTypes.add(type);
                                }
                            }
                        } else {
                            if (val.startsWith("\"")) { //it is a String
                                updateTriples(sbj, attr, null, STRING);
                            } else {
                                System.out.println("Unexpected line: " + l);
                            }
                        }
                    }
                    n++;
                    if (n % 1000000 == 0) {
                        System.out.println("Loaded " + (n / 1000000) + "M triples");
                    }
                } else {
                    System.out.println("Invalid triple: " + l);
                }
                l = in.readLine();
            }
        }
        System.out.println("Entity value triples: " + entityTriplesSubjects.length);
        for (String type : literalTriplesSubjects.keySet()) {
            System.out.println(type + " value triples: " + literalTriplesSubjects.get(type).length);
        }
        attributeUri = new String[attributeIdFromUri.size() + 1];
        for (Map.Entry<String, Short> e : attributeIdFromUri.entrySet()) {
            attributeUri[e.getValue()] = e.getKey();
        }
        entityUriWithPrefix = new String[entityIdFromUriWithPrefix.size() + 1];
        for (Map.Entry<String, Integer> e : entityIdFromUriWithPrefix.entrySet()) {
            entityUriWithPrefix[e.getValue()] = e.getKey();
        }
        //entityUri = new String[entityIdFromUri.size() + 1];
        //for (Map.Entry<String, Integer> e : entityIdFromUri.entrySet()) {
        //    entityUri[e.getValue()] = e.getKey();
        //}
        entityLabels = new HashSet[entityIdFromUriWithPrefix.size() + 1]; //entityLabels = new HashSet[entityIdFromUri.size() + 1];
        entityCategories = new HashSet[entityIdFromUriWithPrefix.size() + 1]; //entityCategories = new HashSet[entityIdFromUri.size() + 1];
        attributeLabels = new HashSet[attributeIdFromUri.size() + 1];
        entityOutAttributes = new HashSet[entityIdFromUriWithPrefix.size() + 1]; //entityOutAttributes = new HashSet[entityIdFromUri.size() + 1];
        entityInAttributes = new HashSet[entityIdFromUriWithPrefix.size() + 1]; //entityInAttributes = new HashSet[entityIdFromUri.size() + 1];
        attributeOutAttributes = new HashSet[attributeIdFromUri.size() + 1];
        attributeInAttributes = new HashSet[attributeIdFromUri.size() + 1];
        attributeHasLiteralRange = new boolean[attributeIdFromUri.size() + 1];
        attributeCount = new int[attributeIdFromUri.size() + 1];
    }
    /*
     The file attribute_labels must contain one row per attribute, with the form
     uri \t label
     e.g.
     http://dbpedia.org/ontology/wimbledonMixed      wimbledon mixed
     uris and labels can be inside angular brackets, e.g.
     <http://dbpedia.org/ontology/wimbledonMixed>      <wimbledon mixed>
     or
     <http://dbpedia.org/ontology/wimbledonMixed>      wimbledon mixed
     or
     http://dbpedia.org/ontology/wimbledonMixed      <wimbledon mixed>
     no other separators are supposed to be used
     The labels of attributes that are not used in triples are ignored
     */

    private void processeAttributeLabelsFile(String fileName) throws Exception {
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + fileName))) {
            String l = in.readLine();
            while (l != null) {
                if (l.length() > 0) {
                    StringTokenizer st = new StringTokenizer(l, "\t<>");
                    String uri = st.nextToken().trim();
                    Short id = attributeIdFromUri.get(uri);
                    if (id != null) { //we ignore the labels of attributes not used in triples
                        try {
                            String label = st.nextToken().trim();
                            if (label.length() > 1) {
                                //System.out.println(uri + "\t" + label);
                                if (attributeLabels[id] == null) {
                                    attributeLabels[id] = new HashSet<>();
                                }
                                attributeLabels[id].add(label);
                                Short idInv = attributeIdFromUri.get(uri + "Inv");
                                if (idInv != null) {
                                    if (attributeLabels[idInv] == null) {
                                        attributeLabels[idInv] = new HashSet<>();
                                    }
                                    attributeLabels[idInv].add(label + " [inverted]");
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            System.out.println("Line: " + l);
                        }
                    }
                }
                l = in.readLine();
            }
        }

    }

    private void loadAttributeLabels() throws Exception {
        System.out.println("Loading attribute labels");
        processeAttributeLabelsFile("attribute_labels");
        System.out.println("Loading additional attribute labels");
        try {
            processeAttributeLabelsFile("additional_attribute_labels");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //now, we drop the attributes without a label from the map of uri -> id
        for (int i = 1; i < attributeLabels.length; i++) {
            if (attributeLabels[i] == null) {
                attributeIdFromUri.remove(attributeUri[i]);
                attributeUri[i] = null;
            }
        }
    }
    /*
     The file category_labels must contain one row per category, with the form
     uri \t label
     e.g.
     http://dbpedia.org/ontology/ProtectedArea       protected area
     uris and labels can be inside angular brackets, e.g.
     <http://dbpedia.org/ontology/ProtectedArea>      <protected area>
     or
     <http://dbpedia.org/ontology/ProtectedArea>      protected area
     or
     http://dbpedia.org/ontology/ProtectedArea      <protected area>
     no other separators are supposed to be used
     */

    private void processCategoryLabelsFile(String fileName, ArrayList<HashSet<String>> labels) throws Exception {
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + fileName))) {
            String l = in.readLine();
            while (l != null) {
                if (l.length() > 0) {
                    StringTokenizer st = new StringTokenizer(l, "\t<>");
                    try {
                        String uri = st.nextToken().trim();
                        String label = st.nextToken().trim();
                        //System.out.println(uri + "\t" + label);
                        if (!categoryIdFromUri.containsKey(uri)) {
                            categoryIdFromUri.put(uri, labels.size() + 1);
                            labels.add(new HashSet<String>());
                            labels.get(labels.size() - 1).add(label);
                        } else {
                            labels.get(categoryIdFromUri.get(uri) - 1).add(label);
                        }
                    } catch (Exception e) {
                        System.out.println("Error with line " + l);
                        e.printStackTrace();
                    }
                }
                l = in.readLine();
            }
        }
    }

    private void loadCategoryLabels() throws Exception {
        ArrayList<HashSet<String>> labels = new ArrayList<>();
        categoryIdFromUri.put(THING, 1);
        thingId = 1;
        labels.add(new HashSet<String>());
        labels.get(0).add("thing");
        System.out.println("Loading category labels");
        processCategoryLabelsFile("category_labels", labels);
        try {
            processCategoryLabelsFile("additional_category_labels", labels);
        } catch (Exception e) {
            e.printStackTrace();
        }
        categoryLabels = new HashSet[labels.size() + 1];
        int i = 1;
        for (HashSet<String> l : labels) {
            categoryLabels[i] = l;
            i++;
        }
        categoryUri = new String[categoryIdFromUri.size() + 1];
        for (Map.Entry<String, Integer> e : categoryIdFromUri.entrySet()) {
            categoryUri[e.getValue()] = e.getKey();
        }
    }
    /*
     The file category_parents must contain one or more rows per category, with the form
     uri \t uri_parent
     e.g.
     http://dbpedia.org/ontology/Actor       http://dbpedia.org/ontology/Artist
     uris can be inside angular brackets, e.g.
     <http://dbpedia.org/ontology/Actor>       <http://dbpedia.org/ontology/Artist>
     or
     <http://dbpedia.org/ontology/Actor>       http://dbpedia.org/ontology/Artist
     or
     http://dbpedia.org/ontology/Actor       <http://dbpedia.org/ontology/Artist>
     no other separators are supposed to be used
     */

    private void loadCategoryHierarchy() throws Exception {
        System.out.println("Loading category parents and building the hierarchy");
        //firs, we initialize category parents
        categoryParents = new HashSet[categoryIdFromUri.size() + 1];
        for (int i = 1; i < categoryParents.length; i++) {
            categoryParents[i] = new HashSet<>();
            //we don't initialize category ancestors because the null value is used to check if the category has not been processed yet
        }
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "category_parents"))) {
            String l = in.readLine();
            while (l != null) {
                if (l.length() > 0) {
                    StringTokenizer st = new StringTokenizer(l, "\t<>");
                    String category = st.nextToken().trim();
                    String parent = st.nextToken().trim();
                    //we are interested only in the hierarchical relationships between
                    //categories defined inside our ontology
                    Integer cId = categoryIdFromUri.get(category);
                    Integer pId = categoryIdFromUri.get(parent);
                    if (cId != null && pId != null && !pId.equals(cId)) {
                        categoryParents[cId].add(pId);
                    }
                }
                l = in.readLine();
            }
            //now add Thing to empty sets of parents
            for (int cId = 1; cId < categoryParents.length; cId++) {
                if (categoryParents[cId].isEmpty()) {
                    categoryParents[cId].add(thingId);
                }
            }
            categoryParents[thingId].clear();
            //now, for each category compute the set of its ancestors
            categoryAncestors = new HashSet[categoryIdFromUri.size() + 1];
            for (int cId = 1; cId < categoryAncestors.length; cId++) {
                computeCategoryAncestors(cId);
            }
            //now, reduce the set of category parents, by keeping only the most specific categories
            for (int cId = 1; cId < categoryParents.length; cId++) {
                HashSet<Integer> currentParents = categoryParents[cId];
                HashSet<Integer> reducedParents = new HashSet<>();
                for (Integer pId : currentParents) {
                    //check if reducedParents contains an ancestor of parent,
                    //or if parent is an ancestor of any category in reducedParents
                    boolean add = true;
                    for (Iterator<Integer> it = reducedParents.iterator(); it.hasNext();) {
                        Integer c = it.next();
                        if (categoryAncestors[c].contains(pId)) {
                            add = false; //we don't add parent, beacause c is a descendant of parent
                            break;
                        } else if (categoryAncestors[pId].contains(c)) {
                            it.remove(); //we remove c beacause parent is a descendant of c
                        }
                    }
                    if (add) {
                        reducedParents.add(pId);
                    }
                }
                categoryParents[cId] = reducedParents;
            }
            //now, compute the category children for each category
            categoryChildren = new HashSet[categoryIdFromUri.size() + 1];
            for (int cId = 1; cId < categoryChildren.length; cId++) {
                categoryChildren[cId] = new HashSet<>();
            }
            for (int cId = 1; cId < categoryParents.length; cId++) {
                for (Integer pId : categoryParents[cId]) {
                    categoryChildren[pId].add(cId);
                }
            }
            //now compute the category descendants for each category
            categoryDescendants = new HashSet[categoryIdFromUri.size() + 1];
            for (int cId = 1; cId < categoryDescendants.length; cId++) {
                computeCategoryDescendants(cId);
            }
        }
    }
    /*
     Compute the set of ancestors of a category
     */

    private void computeCategoryAncestors(int cId) {
        if (categoryAncestors[cId] != null) {
            return; //it was already computed
        }
        categoryAncestors[cId] = new HashSet<>();
        for (Integer pId : categoryParents[cId]) {
            //the parent is an ancestor
            categoryAncestors[cId].add(pId);
            computeCategoryAncestors(pId);
            //and the ancestors of the parent are ancestors as well
            categoryAncestors[cId].addAll(categoryAncestors[pId]);
        }
    }
    /*
     Compute the set of descendants of a category
     */

    private void computeCategoryDescendants(int cId) {
        if (categoryDescendants[cId] != null) {
            return; //it was already computed
        }
        categoryDescendants[cId] = new HashSet<>();
        for (Integer pId : categoryChildren[cId]) {
            //the parent is an ancestor
            categoryDescendants[cId].add(pId);
            computeCategoryDescendants(pId);
            //and the ancestors of the parent are ancestors as well
            categoryDescendants[cId].addAll(categoryDescendants[pId]);
        }
    }
    /*
     The file entity_labels must contain one row per entity, with the form
     uri \t label
     e.g.
     http://dbpedia.org/resource/Agatha_Christie     Agatha Christie
     uris can be inside angular brackets, e.g.
     <http://dbpedia.org/resource/Agatha_Christie>       <Agatha Christie>
     or
     <http://dbpedia.org/resource/Agatha_Christie>       Agatha Christie
     or
     http://dbpedia.org/resource/Agatha_Christie       <Agatha Christie>
     no other separators are supposed to be used
     */

    private void processEntityLabelsFile(String fileName) throws Exception {
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + fileName))) {
            String l = in.readLine();
            while (l != null) {
                if (l.length() > 0) {
                    StringTokenizer st = new StringTokenizer(l, "\t<>");
                    String uri = st.nextToken();
                    Integer id = getEntityIdFromUri(uri); //entityIdFromUri.get(uri);
                    if (id != null) { //we ignore the labels of entities not used in triples
                        try {
                            String label = st.nextToken();
                            //System.out.println(uri + "\t" + label);
                            if (entityLabels[id] == null) {
                                entityLabels[id] = new HashSet<>();
                            }
                            entityLabels[id].add(label);
                        } catch (Exception e) {
                            System.out.println("Failed to add label: " + l);
                        }
                    } else {
                        //System.out.println("Ignored label of "+uri);
                    }
                }
                l = in.readLine();
            }
        }
    }

    private void loadEntityLabels() throws Exception {
        System.out.println("Loading entity labels");
        processEntityLabelsFile("entity_labels");
        try {
            processEntityLabelsFile("additional_entity_labels");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //now, we drop the entities without a label from the map of uri -> id
        for (int i = 1; i < entityLabels.length; i++) {
            if (entityLabels[i] == null) {
                if (DROP_UNLABELED_ENTITIES) {
                    entityIdFromUriWithPrefix.remove(entityUriWithPrefix[i]);//entityIdFromUri.remove(entityUri[i]);
                    entityUriWithPrefix[i] = null; //entityUri[i] = null;
                } else { //create a label
                    entityLabels[i] = new HashSet<>();
                    entityLabels[i].add(entityUriWithPrefix[i]);
                }
            }
        }
    }
    /*
     The file entity_categories must contain one row per pair <entity, category>, with the form
     uri_entity \t uri_category
     e.g.
     http://dbpedia.org/resource/Autism      http://dbpedia.org/ontology/Disease
     uris can be inside angular brackets, e.g.
     <http://dbpedia.org/resource/Autism>      <http://dbpedia.org/ontology/Disease>
     or
     <http://dbpedia.org/resource/Autism>      http://dbpedia.org/ontology/Disease
     or
     http://dbpedia.org/resource/Autism      <http://dbpedia.org/ontology/Disease>
     no other separators are supposed to be used
     */

    private void loadEntityCategories() throws Exception {
        System.out.println("Loading entity categories, and keeping only the most specific");
        int count = 0;
        HashSet<Integer> notEmptyCategories = new HashSet<>();
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "entity_categories"))) {
            String l = in.readLine();
            while (l != null) {
                try {
                    StringTokenizer st = new StringTokenizer(l, "\t<>");
                    String uriE = st.nextToken();
                    String uriC = st.nextToken();
                    Integer idE = getEntityIdFromUri(uriE);//entityIdFromUri.get(uriE);
                    Integer idC = categoryIdFromUri.get(uriC);
                    if (!uriC.equals(THING) && idE != null && idC != null && entityLabels[idE] != null && categoryLabels[idC] != null) {
                        //we ignore the categories without label and the categories of entities not used in triples
                        //we also ignore thing as category, since every entity is implicitly a thing
                        HashSet<Integer> categories = entityCategories[idE];
                        if (categories == null) {
                            categories = new HashSet<>();
                            entityCategories[idE] = categories;
                            count++;
                        }
                        //check if categories contains an ancestor of uriC,
                        //or if uriC is an ancestor of any category in categories
                        boolean add = true;
                        for (Iterator<Integer> it = categories.iterator(); it.hasNext();) {
                            Integer c = it.next();
                            if (categoryAncestors[c].contains(idC)) {
                                add = false; //we don't add category, beacause c is a descendant of category
                                break;
                            } else if (categoryAncestors[idC].contains(c)) {
                                it.remove(); //we remove c beacause uriC is a descendant of c
                            }
                        }
                        if (add) {
                            categories.add(idC);
                            notEmptyCategories.add(idC);
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Failed to load category: " + l);
                }
                l = in.readLine();
            }
        }
        System.out.println(count + " entities have been assigned a non-thing category");
        count = 0;
        //now, set Thing as category of entities without a category
        for (int i = 1; i < entityCategories.length; i++) {
            if (entityCategories[i] == null && entityLabels[i] != null) {
                entityCategories[i] = new HashSet<>();
                entityCategories[i].add(thingId);
                count++;
            }
        }
        System.out.println(count + " entities have been assigned thing category");
        //now drop the categories without entities and without descendant categories - asking for those categories would produce empty results could confuse the user
        for (int i = 1; i < categoryLabels.length; i++) {
            if (i != thingId && !notEmptyCategories.contains(i) && categoryDescendants[i].isEmpty()) {
                categoryLabels[i] = null;
                categoryUri[i] = null;
            }
        }
    }
    /*
     The file basic_type_literal_type must contain one row per basic type, with the form
     uri \t literal_type
     where literal type can be Double, Date, String, Boolean
     e.g.
     http://dbpedia.org/datatype/centimetre  Double
     uri and basic type can be inside angular brackets, e.g.
     <http://dbpedia.org/datatype/centimetre>  <Double>
     or
     <http://dbpedia.org/datatype/centimetre>  <Double>
     or
     <http://dbpedia.org/datatype/centimetre>  <Double>
     no other separators are supposed to be used
     */

    private void loadBasicTypesMapping() throws Exception {
        System.out.println("Loading basic types mappings");
        try (BufferedReader in = new BufferedReader(new FileReader(basePathInput + "basic_types_literal_types"))) {
            String l = in.readLine();
            while (l != null) {
                StringTokenizer st = new StringTokenizer(l, "\t<>");
                String uri = st.nextToken();
                String literal = st.nextToken();
                //System.out.println(uri + "\t" + label);
                basicTypesMapping.put(uri, literal);
                l = in.readLine();
            }
        }
    }

    private void propagateAttributesToDescendantCategories(HashSet<Short>[] categoryAttributes, int category) {
        HashSet<Short> attributes = categoryAttributes[category];
        if (attributes == null) {
            attributes = new HashSet<>();
            categoryAttributes[category] = attributes;
        }
        for (Integer child : categoryChildren[category]) {
            if (categoryAttributes[child] == null) {
                categoryAttributes[child] = new HashSet<>();
            }
            categoryAttributes[child].addAll(attributes);
            propagateAttributesToDescendantCategories(categoryAttributes, child);
        }
    }

    private void propagateAttributesToAncestorCategories(HashSet<Short>[] categoryAttributes, int category) {
        for (int childCategory : categoryChildren[category]) {
            propagateAttributesToAncestorCategories(categoryAttributes, childCategory);
        }
        HashSet<Short> attributes = categoryAttributes[category];
        if (attributes == null) {
            attributes = new HashSet<>();
            categoryAttributes[category] = attributes;
        }
        for (Integer child : categoryChildren[category]) {
            attributes.addAll(categoryAttributes[child]);
        }
    }

    private HashSet<Integer> findCommonLowestAncestor(int c1, int c2) {
        HashSet<Integer> res = new HashSet<>();
        if (c1 == c2) {
            res.add(c1);
            return res;
        }
        if (categoryAncestors[c1].contains(c2)) {
            res.add(c2);
            return res;
        } else if (categoryAncestors[c2].contains(c1)) {
            res.add(c1);
            return res;
        }
        //find common ancestors
        HashSet<Integer> temp = new HashSet<>();
        for (int a : categoryAncestors[c1]) {
            if (categoryAncestors[c2].contains(a)) {
                temp.add(a);
            }
        }
        for (int candidateCategory : temp) {
            boolean add = true;
            for (Iterator<Integer> it = res.iterator(); it.hasNext();) {
                int existingCategory = it.next();
                if (categoryAncestors[existingCategory].contains(candidateCategory)) { //candidate category is an ancestor of existing category
                    add = false;
                    break;
                } else if (categoryAncestors[candidateCategory].contains(existingCategory)) { //existing category is an ancestor of candodate category
                    it.remove();
                    //don't break - candidate category could be the ancestor of other existing categories in res
                }
            }
            if (add) {
                res.add(candidateCategory);
            }
        }
        return res;
    }

    private HashSet<Integer> findCommonLowestAncestor(Set<Integer> categories) {
        HashSet<Integer> finalCategories = new HashSet<>(categories);
        while (finalCategories.size() > 1) {
            Iterator<Integer> it = finalCategories.iterator();
            int c1 = it.next();
            it.remove();
            int c2 = it.next();
            it.remove();
            HashSet<Integer> cas = findCommonLowestAncestor(c1, c2);
            for (int ca : cas) {
                finalCategories.add(ca);
            }
        }
        return finalCategories;
    }

    private void updateOutAndInEntityAndLiteralTypeAttributes(Short attribute, Integer subj, Integer entityVal, String literalType) {
        if (entityOutAttributes[subj] == null) {
            entityOutAttributes[subj] = new HashSet<>();
        }
        entityOutAttributes[subj].add(attribute);
        if (entityVal != null) {
            if (entityInAttributes[entityVal] == null) {
                entityInAttributes[entityVal] = new HashSet<>();
            }
            entityInAttributes[entityVal].add(attribute);
        }
        if (literalType != null) {
            literalTypesInAttributes.get(literalType).add(attribute);
        }
    }

    private void processTriples() throws Exception {
        int droppedEntityTriples = 0;
        int droppedLiteralTriples = 0;
        System.out.println("Dropping triples with undefined elements");
        for (int i = 0; i < entityTriplesSubjects.length; i++) {
            int sbj = entityTriplesSubjects[i];
            int val = entityTriplesValues[i];
            short attr = entityTriplesAttributes[i];
            if (entityUriWithPrefix[sbj] == null || entityUriWithPrefix[val] == null || attributeUri[attr] == null) {//if (entityUri[sbj] == null || entityUri[val] == null || attributeUri[attr] == null) {
                entityTriplesSubjects[i] = 0;
                droppedEntityTriples++;
            } else {
                attributeCount[attr]++;
            }
        }
        for (String type : literalTypes) {
            for (int i = 0; i < literalTriplesSubjects.get(type).length; i++) {
                int sbj = literalTriplesSubjects.get(type)[i];
                short attr = literalTriplesAttributes.get(type)[i];
                if (entityUriWithPrefix[sbj] == null || attributeUri[attr] == null) {//if (entityUri[sbj] == null || attributeUri[attr] == null) {
                    literalTriplesSubjects.get(type)[i] = 0;
                    droppedLiteralTriples++;
                } else {
                    attributeCount[attr]++;
                }
            }
        }
        System.out.println("Dropped " + droppedEntityTriples + " triples with entity value and " + droppedLiteralTriples + " with literal value");

        System.out.println("Scanning the triples to compute out-attributes of entities and in-attributes of entities and literal basic types");
        //first compute out-attributes and in-attributes of entities
        //and in-attributes of basic types
        //<sbj, attr, val>, where val is an entity -> add attr to out-attributes of sbj and in-attributes of val
        int c = 0;
        for (int i = 0; i < entityTriplesSubjects.length; i++) {
            if (entityTriplesSubjects[i] == 0) { //it was previously dropped
                continue;
            }
            int sbj = entityTriplesSubjects[i];
            short attr = entityTriplesAttributes[i];
            int val = entityTriplesValues[i];
            if (entityUriWithPrefix[sbj] != null && attributeUri[attr] != null && entityUriWithPrefix[val] != null) {//if (entityUri[sbj] != null && attributeUri[attr] != null && entityUri[val] != null) {
                updateOutAndInEntityAndLiteralTypeAttributes(attr, sbj, val, null);
            }
            c++;
            if (c % 1000000 == 0) {
                System.out.println("Processed " + (c / 1000000) + "M triples");
            }
        }
        entityTriplesSubjects = null;
        entityTriplesAttributes = null;
        entityTriplesValues = null;
        System.gc();
        //<sbj, attr, type>, where type is a basic type -> add attr to out-attributes of sbj and in-attributes of type
        for (String literalType : literalTypes) {
            for (int i = 0; i < literalTriplesSubjects.get(literalType).length; i++) {
                if (literalTriplesSubjects.get(literalType)[i] == 0) { //it was previously dropped
                    continue;
                }
                int sbj = literalTriplesSubjects.get(literalType)[i];
                short attr = literalTriplesAttributes.get(literalType)[i];
                if (entityUriWithPrefix[sbj] != null && attributeUri[attr] != null) {//if (entityUri[sbj] != null && attributeUri[attr] != null) {
                    updateOutAndInEntityAndLiteralTypeAttributes(attr, sbj, null, literalType);
                    attributeHasLiteralRange[attr] = true;
                }
                c++;
                if (c % 1000000 == 0) {
                    System.out.println("Processed " + (c / 1000000) + "M triples");
                }
            }
        }
        literalTriplesSubjects = null;
        literalTriplesAttributes = null;
        System.gc();
        System.out.println("Scanning the entity out-attributes to compute out-attributes of categories");
        //now it is possible to compute the out-attributes and in-attributes of categories
        //entityOutAttributes of e contains a -> add a to categoryOutAttributes of all the categories of e
        categoryOutAttributes = new HashSet[categoryUri.length];
        for (int i = 1; i < entityOutAttributes.length; i++) {
            if (entityOutAttributes[i] != null && entityCategories[i] != null) {
                for (short attribute : entityOutAttributes[i]) {
                    for (int category : entityCategories[i]) {
                        if (categoryOutAttributes[category] == null) {
                            categoryOutAttributes[category] = new HashSet<>();
                        }
                        categoryOutAttributes[category].add(attribute);
                    }
                }
            }
        }
        //System.out.println("Propagating the out-attributes to descendant categories");
        //propagateAttributesToDescendantCategories(categoryOutAttributes, thingId);
        System.out.println("Propagating the out-attributes to ancestor categories");
        propagateAttributesToAncestorCategories(categoryOutAttributes, thingId);
        if (printFiles) {
            System.out.println("Writing the categoryOutAttributes");
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "category_out_attributes", false), true)) {
                for (int i = 1; i < categoryOutAttributes.length; i++) {
                    if (i % 10 == 0) {
                        out.flush();
                    }
                    if (categoryOutAttributes[i] != null) {
                        out.print(categoryUri[i]);
                        for (Short a : categoryOutAttributes[i]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        /*
                         System.out.print(categoryLabels[i] + " - outAttributes: ");
                         for (Integer a : categoryOutAttributes[i]) {
                         System.out.print("\t" + attributeLabels[a]);
                         }
                         System.out.println();*/
                    }
                }
            }
        }
        System.out.println("Scanning the entity in-attributes to compute in-attributes of categories");
        //entityInAttributes of e contains a -> add a to categoryInAttributes of all the categories of e
        categoryInAttributes = new HashSet[categoryUri.length];
        for (int i = 1; i < entityInAttributes.length; i++) {
            if (entityInAttributes[i] != null && entityCategories[i] != null) {
                for (short attribute : entityInAttributes[i]) {
                    for (int category : entityCategories[i]) {
                        if (categoryInAttributes[category] == null) {
                            categoryInAttributes[category] = new HashSet<>();
                        }
                        categoryInAttributes[category].add(attribute);
                    }
                }
            }
        }
        //System.out.println("Propagating the in-attributes to descendant categories");
        //propagateAttributesToDescendantCategories(categoryInAttributes, thingId);
        System.out.println("Propagating the in-attributes to ancestor categories");
        propagateAttributesToAncestorCategories(categoryOutAttributes, thingId);
        if (printFiles) {
            System.out.println("Writing the categoryInAttributes");
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "category_in_attributes", false), true)) {
                for (int i = 1; i < categoryInAttributes.length; i++) {
                    if (i % 10 == 0) {
                        out.flush();
                    }
                    if (categoryInAttributes[i] != null) {
                        out.print(categoryUri[i]);
                        for (Short a : categoryInAttributes[i]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        /*
                         System.out.print(categoryLabels[i] + " - inAttributes: ");
                         for (Integer a : categoryInAttributes[i]) {
                         System.out.print("\t" + attributeLabels[a]);
                         }
                         System.out.println();*/
                    }
                }
            }
        }
        System.out.println("Scanning the triples to compute out- and in-attributes of attributes");
        //now it is possible to compute the out-attributes and in-attributes of attributes
        //<t[0], t[1], t[2]> -> add t[1] to outAttributes[attribute] for each attribute in entityInAttributes[t[0]]
        /* OLD WAY
         c = 0;
         attributeOutAttributes = new HashSet[attributeUri.length];
         for (int[] t : entityTriples) {
         if (entityInAttributes[t[0]] != null) {
         for (int attribute : entityInAttributes[t[0]]) {
         if (attributeOutAttributes[attribute] == null) {
         attributeOutAttributes[attribute] = new HashSet<>();
         }
         attributeOutAttributes[attribute].add(t[1]);
         }
         }
         c++;
         if (c % 1000000 == 0) {
         System.out.println("Processed " + (c / 1000000) + "M triples");
         }
         }
         for (LinkedList<int[]> lt : literalTriples.values()) {
         for (int[] t : lt) {
         if (entityInAttributes[t[0]] != null) {
         for (int attribute : entityInAttributes[t[0]]) {
         if (attributeOutAttributes[attribute] == null) {
         attributeOutAttributes[attribute] = new HashSet<>();
         }
         attributeOutAttributes[attribute].add(t[1]);
         }
         }
         c++;
         if (c % 1000000 == 0) {
         System.out.println("Processed " + (c / 1000000) + "M triples");
         }
         }
         }
         */
        for (int entity = 1; entity < entityInAttributes.length; entity++) {
            if (entityInAttributes[entity] != null) {
                for (int attribute : entityInAttributes[entity]) {
                    if (entityOutAttributes[entity] != null && !entityOutAttributes[entity].isEmpty()) {
                        if (attributeOutAttributes[attribute] == null) {
                            attributeOutAttributes[attribute] = new HashSet<>();
                        }
                        attributeOutAttributes[attribute].addAll(entityOutAttributes[entity]);
                    }
                    if (attributeInAttributes[attribute] == null) {
                        attributeInAttributes[attribute] = new HashSet<>();
                    }
                    attributeInAttributes[attribute].addAll(entityInAttributes[entity]);
                }
            }
        }
        //I will use the literalTypesInAttributes when I index the attribute with rangeOf
        /*
         for (String type : literalTypes) {
         for (int attribute : literalTypesInAttributes.get(type)) {
         if (attributeInAttributes[attribute] == null) {
         attributeInAttributes[attribute] = new HashSet<>();
         }
         attributeInAttributes[attribute].addAll(literalTypesInAttributes.get(type));
         }
         }
         */
        //System.out.println("Scanning the triples to compute in-attributes of attributes");
        //<t[0], t[1], t[2]> -> add t[1] to inAttributes[attribute] for each attribute in entityInAttributes[t[2]]
        /*OLD WAY
         c = 0;
         attributeInAttributes = new HashSet[attributeUri.length];
         for (int[] t : entityTriples) {
         if (entityInAttributes[t[2]] != null) {
         for (int attribute : entityInAttributes[t[2]]) {
         if (attributeInAttributes[attribute] == null) {
         attributeInAttributes[attribute] = new HashSet<>();
         }
         attributeInAttributes[attribute].add(t[1]);
         }
         }
         c++;
         if (c % 1000000 == 0) {
         System.out.println("Processed " + (c / 1000000) + "M triples");
         }
         }
         //<t[0], t[1], type> -> add t[1] to inAttributes[attribute] for each attribute in literalValueInAttributes[type]
         //it is possible to avoid the scan of the triples, since we already know the inAttribute of each literal basic type
         for (String type : literalTriples.keySet()) {
         for (int attribute1 : literalTypesInAttributes.get(type)) {
         if (attributeInAttributes[attribute1] == null) {
         attributeInAttributes[attribute1] = new HashSet<>();
         }
         for (int attribute2 : literalTypesInAttributes.get(type)) {
         attributeInAttributes[attribute1].add(attribute2);
         }
         }
         }
         */
        //write the in/Out-Entity/Category-Attributes
        if (printFiles) {
            System.out.println("Writing the entityInAttributes");
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "entity_in_attributes", false), true)) {
                for (int i = 1; i < entityInAttributes.length; i++) {
                    if (i % 100 == 0) {
                        out.flush();
                    }
                    if (entityInAttributes[i] != null) {
                        out.print(entityUriWithPrefix[i]);//out.print(entityUri[i]);
                        for (Short a : entityInAttributes[i]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        if (i % 100000 == 0) {
                            System.out.print(entityLabels[i] + " - inAttributes: ");
                            for (Short a : entityInAttributes[i]) {
                                System.out.print("\t" + attributeLabels[a]);
                            }
                            System.out.println();
                        }
                    }
                }
            }
        }
        if (printFiles) {
            System.out.println("Writing the entityOutAttributes");
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "entity_out_attributes", false), true)) {
                for (int i = 1; i < entityOutAttributes.length; i++) {
                    if (i % 100 == 0) {
                        out.flush();
                    }
                    if (entityOutAttributes[i] != null) {
                        out.print(entityUriWithPrefix[i]);//out.print(entityUri[i]);
                        for (Short a : entityOutAttributes[i]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        if (i % 100000 == 0) {
                            System.out.print(entityLabels[i] + " - outAttributes: ");
                            for (Short a : entityOutAttributes[i]) {
                                System.out.print("\t" + attributeLabels[a]);
                            }
                            System.out.println();
                        }
                    }
                }
            }
        }
        //write the literalInAttributes
        if (printFiles) {
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "literal_types_in_attributes", false), true)) {
                for (Map.Entry<String, HashSet<Short>> e : literalTypesInAttributes.entrySet()) {
                    out.print(e.getKey());
                    for (Short a : e.getValue()) {
                        out.print("\t" + attributeUri[a]);
                    }
                    out.println();
                    /*
                     System.out.print(e.getKey() + " - inAttributes: ");
                     for (Integer a : e.getValue()) {
                     System.out.print("\t" + attributeLabels[a]);
                     }
                     System.out.println();
                     */
                }
            }
        }
        if (printFiles) {
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "attribute_in_attributes", false), true)) {
                for (int attribute = 1; attribute < attributeUri.length; attribute++) {
                    if (attribute % 10 == 0) {
                        out.flush();
                    }
                    if (attributeInAttributes[attribute] != null && !attributeInAttributes[attribute].isEmpty()) {
                        out.print(attributeUri[attribute]);
                        for (Short a : attributeInAttributes[attribute]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        /*
                         System.out.print(attributeLabels[attribute] + " - inAttributes: ");
                         for (Integer a : attributeInAttributes[attribute]) {
                         System.out.print("\t" + attributeLabels[a]);
                         }
                         System.out.println();
                         */
                    }
                }
            }
        }
        if (printFiles) {
            try (PrintWriter out = new PrintWriter(new FileOutputStream(basePathOutput + "attribute_out_attributes", false), true)) {
                for (int attribute = 1; attribute < attributeUri.length; attribute++) {
                    if (attribute % 10 == 0) {
                        out.flush();
                    }
                    if (attributeOutAttributes[attribute] != null && !attributeOutAttributes[attribute].isEmpty()) {
                        out.print(attributeUri[attribute]);
                        for (Short a : attributeOutAttributes[attribute]) {
                            out.print("\t" + attributeUri[a]);
                        }
                        out.println();
                        /*
                         System.out.print(attributeLabels[attribute] + " - outAttributes: ");
                         for (Integer a : attributeOutAttributes[attribute]) {
                         System.out.print("\t" + attributeLabels[a]);
                         }
                         System.out.println();
                         */
                    }
                }
            }
        }
    }

    private static void indexOntologyElement(IndexWriter writer, OntologyElementToken e, Collection<String> domainOf, Collection<String> rangeOf, Collection<String> extendedDomain) throws Exception {
        Document doc = new Document();
        doc.add(new Field("label", e.getLabel(), TextField.TYPE_NOT_STORED));
        doc.add(new IntField("id", e.getId(), IntField.TYPE_STORED));
        doc.add(new Field("type", e.getType(), StringField.TYPE_NOT_STORED));
        if (domainOf != null) {
            for (String d : domainOf) { //the first element is the URI
                doc.add(new Field("domainOfAttribute", d, StringField.TYPE_NOT_STORED));
            }
        }
        if (rangeOf != null) {
            for (String r : rangeOf) { //the first element is the URI
                doc.add(new Field("rangeOfAttribute", r, StringField.TYPE_NOT_STORED));
            }
        }
        if (extendedDomain != null) {
            for (String d : extendedDomain) { //the first element is the URI
                doc.add(new Field("attributeDomain", d, StringField.TYPE_NOT_STORED));
            }
        }
        writer.addDocument(doc);
    }
    /*
     private static void indexNonOntologyElement(IndexWriter writer, IndexedToken e, Collection<String> domainOf, Collection<String> rangeOf, Collection<String> extendedDomain) throws Exception {
     Document doc = new Document();
     doc.add(new Field("label", e.getText(), TextField.TYPE_NOT_STORED));
     doc.add(new Field("id", e.getId(), TextField.TYPE_STORED));
     doc.add(new Field("type", e.getType(), TextField.TYPE_NOT_STORED));
     if (domainOf != null) {
     for (String d : domainOf) { //the first element is the URI
     doc.add(new Field("domainOfAttribute", d, StringField.TYPE_NOT_STORED));
     }
     }
     if (rangeOf != null) {
     for (String r : rangeOf) { //the first element is the URI
     doc.add(new Field("rangeOfAttribute", r, StringField.TYPE_NOT_STORED));
     }
     }
     if (extendedDomain != null) {
     for (String d : extendedDomain) { //the first element is the URI
     doc.add(new Field("attributeDomain", d, StringField.TYPE_NOT_STORED));
     }
     }
     writer.addDocument(doc);
     }
     */

    private void indexEntities(IndexWriter writer, HashMap<Integer, IndexedToken> elements) throws Exception {
        for (int i = 1; i < entityUriWithPrefix.length; i++) {//for (int i = 1; i < entityUri.length; i++) {
            if (entityUriWithPrefix[i] != null) {//if (entityUri[i] != null) {
                HashSet<String> domainOf = new HashSet<>();
                HashSet<String> rangeOf = new HashSet<>();
                if (entityOutAttributes[i] != null) {
                    for (int a : entityOutAttributes[i]) {
                        domainOf.add(attributeUri[a]);
                    }
                }
                if (entityInAttributes[i] != null) {
                    for (int a : entityInAttributes[i]) {
                        rangeOf.add(attributeUri[a]);
                    }
                }
                for (String label : entityLabels[i]) {
                    EntityToken element = new EntityToken(getEntityCompleteUri(entityUriWithPrefix[i]), label, false);//EntityToken element = new EntityToken(entityUri[i], label);
                    indexOntologyElement(writer, element, domainOf, rangeOf, null);
                    elements.put(element.getId(), element);
                }
            }
        }
        entityOutAttributes = null;
        entityInAttributes = null;
        System.gc();
    }

    private void indexCategories(IndexWriter writer, HashMap<Integer, IndexedToken> elements) throws Exception {
        HashSet<Character> vowels = new HashSet<>();
        vowels.add('a');
        vowels.add('e');
        vowels.add('i');
        vowels.add('o');
        vowels.add('u');
        for (int i = 1; i < categoryUri.length; i++) {
            if (categoryUri[i] != null) {
                HashSet<String> domainOf = new HashSet<>();
                HashSet<String> rangeOf = new HashSet<>();
                if (categoryOutAttributes[i] == null) {
                    categoryOutAttributes[i] = new HashSet<>();
                }
                for (int a : categoryOutAttributes[i]) {
                    domainOf.add(attributeUri[a]);
                }
                if (categoryInAttributes[i] == null) {
                    categoryInAttributes[i] = new HashSet<>();
                }
                for (int a : categoryInAttributes[i]) {
                    rangeOf.add(attributeUri[a]);
                }
                for (String label : categoryLabels[i]) {
                    label = label.toLowerCase();
                    CategoryToken elementSingular = new CategoryToken(categoryUri[i], label, IndexedToken.SINGULAR, false);
                    indexOntologyElement(writer, elementSingular, domainOf, rangeOf, null);
                    elements.put(elementSingular.getId(), elementSingular);
                    //now create the plural form
                    String pLabel;
                    if (label.endsWith("y") && !vowels.contains(label.charAt(label.length() - 2))) {
                        pLabel = label.substring(0, label.length() - 1) + "ies";
                    } else if (label.endsWith("s") || label.endsWith("sh") || label.endsWith("ch") || label.endsWith("x") || label.endsWith("z")) {
                        pLabel = label + "es";
                    } else if (label.equals("person")) {
                        pLabel = "people";
                    } else {
                        pLabel = label + "s";
                    }
                    CategoryToken elementPlural = new CategoryToken(categoryUri[i], pLabel, IndexedToken.PLURAL, false);
                    indexOntologyElement(writer, elementPlural, domainOf, rangeOf, null);
                    elements.put(elementPlural.getId(), elementPlural);
                }
            }
        }
    }

    private void indexAttributes(IndexWriter writer, HashMap<Integer, IndexedToken> elements) throws Exception {
        //precompute the domains of attributes
        HashSet<String>[] attributeDomains = new HashSet[attributeUri.length];
        //the domain of an attribute a is the set of categories and attributes having a in their outAttribute
        for (int category = 1; category < categoryOutAttributes.length; category++) {
            if (categoryOutAttributes[category] != null && categoryUri[category] != null) {
                for (int a : categoryOutAttributes[category]) {
                    if (attributeDomains[a] == null) {
                        attributeDomains[a] = new HashSet<>();
                    }
                    attributeDomains[a].add(categoryUri[category]);
                }
            }
        }
        for (int attribute = 1; attribute < attributeOutAttributes.length; attribute++) {
            if (attributeOutAttributes[attribute] != null) {
                for (int a : attributeOutAttributes[attribute]) {
                    if (attributeDomains[a] == null) {
                        attributeDomains[a] = new HashSet<>();
                    }
                    attributeDomains[a].add(attributeUri[attribute]);
                }
            }
        }
        //precompute the literal ranges of every attribute
        HashSet<String>[] attributeLiteralRanges = new HashSet[attributeUri.length];
        for (int i = 1; i < attributeLiteralRanges.length; i++) {
            attributeLiteralRanges[i] = new HashSet<>();
        }
        for (String literalType : literalTypesInAttributes.keySet()) {
            for (int attribute : literalTypesInAttributes.get(literalType)) {
                attributeLiteralRanges[attribute].add(literalType);
            }
        }
        for (short attribute = 1; attribute < attributeUri.length; attribute++) {
            if (attributeUri[attribute] != null) {
                HashSet<String> domainOf = new HashSet<>();
                if (attributeOutAttributes[attribute] != null) {
                    for (int a : attributeOutAttributes[attribute]) {
                        domainOf.add(attributeUri[a]);
                    }
                }
                HashSet<String> rangeOf = new HashSet<>();
                if (attributeInAttributes[attribute] != null) {
                    for (int a : attributeInAttributes[attribute]) {
                        rangeOf.add(attributeUri[a]);
                    }
                }
                for (String type : literalTypes) {
                    if (literalTypesInAttributes.get(type).contains(attribute)) {
                        for (short a : literalTypesInAttributes.get(type)) {
                            rangeOf.add(attributeUri[a]);
                        }
                    }
                }
                for (String label : attributeLabels[attribute]) {
                    HashSet<String> aDomains = attributeDomains[attribute];
                    AttributeToken element = new AttributeToken(attributeUri[attribute], label, IndexedToken.UNDEFINED, IndexedToken.UNDEFINED, attributeOutAttributes[attribute] != null && !attributeOutAttributes[attribute].isEmpty(), attributeHasLiteralRange[attribute], false);
                    indexOntologyElement(writer, element, domainOf, rangeOf, aDomains);
                    element.setAttributeAndCategoryDomain(aDomains);
                    element.addBasicTypeRanges(attributeLiteralRanges[attribute]);
                    elements.put(element.getId(), element);
                }
            }
        }
        categoryOutAttributes = null;
        categoryInAttributes = null;
        attributeOutAttributes = null;
        attributeInAttributes = null;
        System.gc();
    }

    public void start() throws Exception {
        long t = System.currentTimeMillis();
        loadBasicTypesMapping();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadTriples();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadAttributeLabels();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadCategoryLabels();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadCategoryHierarchy();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadEntityLabels();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        loadEntityCategories();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        entityIdFromUriWithPrefix = null;//entityIdFromUri = null;
        categoryIdFromUri = null;
        attributeIdFromUri = null;
        System.gc();
        processTriples();
        System.out.println(System.currentTimeMillis() - t);
        t = System.currentTimeMillis();
        HashMap<String, Analyzer> analyzerMap = new HashMap<>();
        analyzerMap.put("label", new EnglishAnalyzer(CharArraySet.EMPTY_SET));
        analyzerMap.put("id", new WhitespaceAnalyzer());
        analyzerMap.put("type", new WhitespaceAnalyzer());
        analyzerMap.put("domainOfAttribute", new WhitespaceAnalyzer());
        analyzerMap.put("rangeOfAttribute", new WhitespaceAnalyzer());
        analyzerMap.put("attributeDomain", new WhitespaceAnalyzer());
        Analyzer analyzer = new PerFieldAnalyzerWrapper(new WhitespaceAnalyzer(), analyzerMap);
        HashMap<Integer, IndexedToken> elements = new HashMap<>();
        try (FSDirectory directory = FSDirectory.open(Paths.get(basePathOutput + "lucene"))) {
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
            iwc.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
            try (IndexWriter writer = new IndexWriter(directory, iwc)) {
                System.out.println("Indexing entities");
                indexEntities(writer, elements);
                System.out.println(System.currentTimeMillis() - t);
                t = System.currentTimeMillis();
                System.out.println("Indexing categories");
                indexCategories(writer, elements);
                System.out.println(System.currentTimeMillis() - t);
                t = System.currentTimeMillis();
                System.out.println("Indexing attributes");
                indexAttributes(writer, elements);
                System.out.println(System.currentTimeMillis() - t);
                t = System.currentTimeMillis();
                /*
                 System.out.println("Indexing constraint uriToPrefix");
                 indexConstraintPrefixes(writer, elements);
                 System.out.println(System.currentTimeMillis() - t);
                 t = System.currentTimeMillis();
                 */
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //save elements to file
        System.out.println("Creating the trie");
        Trie trie = new Trie();
        int c=0;
        for (IndexedToken it : elements.values()) {
            trie.add(it.getText());
            c++;
            if (c%100000==0) {
                System.out.println(c+" elements added to the trie");
            }
        }
        System.out.println(c+" elements added to the trie");
        c=0;
        for (IndexedToken it : elements.values()) {
            String suffix = trie.getOneSuffix(it.getText());
            if (suffix != null) {
                it.setPrefix(true);
                c++;
            }
        }
        System.out.println(c+" are prefix of another elements");
        System.out.println("Serializing the tokens");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(basePathOutput + "elements"))) {
            oos.writeObject(elements);
            oos.writeInt(IndexedToken.counter);
        }
    }

    public static void main(String... args) throws Exception {
        String fn1 = null, fn2 = null;
        if (args != null && args.length > 0) {
            fn1 = args[0];
            if (args.length > 1) {
                fn2 = args[1];
            } else {
                //fn2 = "/home/massimo/aquawd/processed-dbpedia-ontology-extended/";
                //fn2 = "/home/massimo/aquawd/processed-dbpedia-ontology/";
                fn2 = "/home/massimo/aquawd/processed-biomedical-ontology/";
            }
        } else {
            //fn1 = "/home/massimo/aquawd/dbpedia-ontology-extended-files/";
            //fn2 = "/home/massimo/aquawd/processed-dbpedia-ontology-extended/";
            //fn1 = "/home/massimo/aquawd/dbpedia-ontology-files/";
            //fn2 = "/home/massimo/aquawd/processed-dbpedia-ontology/";
            //fn1 = "/home/massimo/aquawd/musicbrainz-old-ontology-files/";
            //fn2 = "/home/massimo/aquawd/processed-musicbrainz-old-ontology/";
            fn1 = "/home/massimo/aquawd/biomedical-ontology-files/";
            fn2 = "/home/massimo/aquawd/processed-biomedical-ontology/";            
        }
        long start = System.currentTimeMillis();
        System.out.println("Started at " + new Date());
        new BuildIndex(fn1, fn2).start();
        //new BuildIndex("/home/massimo/aquawd/dbpedia-ontology-files/", "/home/massimo/aquawd/processed-dbpedia-ontology/").start();
        //new BuildIndex("/home/massimo/aquawd/dbpedia-ontology-extended-files/", "/home/massimo/aquawd/processed-dbpedia-ontology-extended/").start();
        //new BuildIndex("/home/massimo/aquawd/biomedical-ontology-files-shirley/", "/home/massimo/aquawd/processed-biomedical-ontology/").start();
        System.out.println("Ended at " + new Date());
        long time = System.currentTimeMillis() - start;
        long sec = time / 1000;
        System.out.println("The process took " + (sec / 60) + "'" + (sec % 60) + "." + (time % 1000) + "\"");
    }
}
