/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.index;

import edu.ucla.cs.scai.swims.canali.index.tokens.RankOperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.LiteralDateToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.LiteralToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.QuestionStartToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.LiteralStringToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.PossessiveDeterminerToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.DirectBinaryOperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.LiteralNumericToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.UnaryOperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.IndexedToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.TopKOperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.LiteralPercentageToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.IndirectBinaryOperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.AttributeToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.ConstraintPrefixToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.OntologyElementToken;
import static edu.ucla.cs.scai.swims.canali.index.tokens.LiteralToken.*;
import edu.ucla.cs.scai.swims.canali.index.tokens.OperatorToken;
import edu.ucla.cs.scai.swims.canali.index.tokens.RankCountOperatorToken;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IOContext;
import org.apache.lucene.store.RAMDirectory;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
public class TokenIndex {

                                                                                                                                                                                                                                            static final String PATH = "/home/massimo/aquawd/processed-dbpedia-ontology-extended/";
    //static final String PATH = "/home/massimo/aquawd/processed-dbpedia-ontology/";
    //static final String PATH = "/home/massimo/aquawd/processed-biomedical-ontology/";
    //static final String PATH = "/home/massimo/aquawd/processed-musicbrainz-old-ontology/";
    protected static HashMap<Integer, IndexedToken> elements;
    protected static HashMap<String, Integer> ontologyElementsIdByUri;
    protected static final Analyzer analyzer;
    protected static final Directory directory;

    static {
        HashMap<String, Analyzer> analyzerMap = new HashMap<>();
        analyzerMap.put("label", new EnglishAnalyzer(CharArraySet.EMPTY_SET));
        analyzerMap.put("id", new WhitespaceAnalyzer());
        analyzerMap.put("type", new WhitespaceAnalyzer());
        analyzerMap.put("domainOf", new WhitespaceAnalyzer());
        analyzerMap.put("rangeOf", new WhitespaceAnalyzer());
        analyzer = new PerFieldAnalyzerWrapper(new WhitespaceAnalyzer(), analyzerMap);
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(PATH + "elements"))) {
            System.out.println("Loading ontology elements from disk");
            elements = (HashMap<Integer, IndexedToken>) in.readObject();
            ontologyElementsIdByUri = new HashMap<>();
            for (IndexedToken e : elements.values()) {
                if (e instanceof OntologyElementToken) {
                    ontologyElementsIdByUri.put(((OntologyElementToken) e).getUri(), e.getId());
                }
            }
            IndexedToken.counter = in.readInt();
        } catch (Exception ex) {
            Logger.getLogger(TokenIndex.class.getName()).log(Level.SEVERE, null, ex);
        }
        directory = initDirectory();
    }

    private static RAMDirectory initDirectory() {
        RAMDirectory directory = new RAMDirectory();
        FSDirectory tempDirectory;
        System.out.println("Loading ontology index from disk");
        try {
            tempDirectory = FSDirectory.open(Paths.get(PATH + "lucene"));
            for (String file : tempDirectory.listAll()) {
                directory.copyFrom(tempDirectory, file, file, IOContext.DEFAULT);
            }
        } catch (IOException ex) {
            Logger.getLogger(TokenIndex.class.getName()).log(Level.SEVERE, null, ex);
        }
        IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
        iwc.setOpenMode(IndexWriterConfig.OpenMode.APPEND);
        try (IndexWriter writer = new IndexWriter(directory, iwc)) {
            indexQuestionStarts(writer);
            indexConstraintPrefixes(writer);
            indexOperators(writer);
            indexPossessiveAdjective(writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return directory;
    }

    private static void addElement(IndexWriter writer, IndexedToken e) throws Exception {
        Document doc = new Document();
        doc.add(new Field("label", e.getText(), TextField.TYPE_NOT_STORED));
        doc.add(new IntField("id", e.getId(), IntField.TYPE_STORED));
        doc.add(new Field("type", e.getType(), TextField.TYPE_NOT_STORED));
        writer.addDocument(doc);
        elements.put(e.getId(), e);
    }

    private static void indexQuestionStarts(IndexWriter writer) throws Exception {
        addElement(writer, new QuestionStartToken("Give me the", IndexedToken.UNDEFINED, QuestionStartToken.PLAIN, true));
        addElement(writer, new QuestionStartToken("Give me the count of", IndexedToken.PLURAL, QuestionStartToken.COUNT, false));
        addElement(writer, new QuestionStartToken("What is", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, true));
        addElement(writer, new QuestionStartToken("What is the", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, true));
        addElement(writer, new QuestionStartToken("What is the count of", IndexedToken.PLURAL, QuestionStartToken.COUNT, false));
        addElement(writer, new QuestionStartToken("What are", IndexedToken.PLURAL, QuestionStartToken.PLAIN, true));
        addElement(writer, new QuestionStartToken("What are the", IndexedToken.PLURAL, QuestionStartToken.PLAIN, false));
        addElement(writer, new QuestionStartToken("What has", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, false));
        addElement(writer, new QuestionStartToken("Who has", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, false));                
        addElement(writer, new QuestionStartToken("Who is", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, true));        
        addElement(writer, new QuestionStartToken("Who is the", IndexedToken.SINGULAR, QuestionStartToken.PLAIN, false));        
        addElement(writer, new QuestionStartToken("Who are the", IndexedToken.PLURAL, QuestionStartToken.PLAIN, false));
        addElement(writer, new QuestionStartToken("Is", IndexedToken.SINGULAR, QuestionStartToken.YESNO, true));
        addElement(writer, new QuestionStartToken("Is the", IndexedToken.SINGULAR, QuestionStartToken.YESNO, false));
        addElement(writer, new QuestionStartToken("Is there a", IndexedToken.SINGULAR, QuestionStartToken.YESNO, false));        
        addElement(writer, new QuestionStartToken("Are", IndexedToken.PLURAL, QuestionStartToken.YESNO, true));
        addElement(writer, new QuestionStartToken("Are the", IndexedToken.PLURAL, QuestionStartToken.YESNO, false));        
        addElement(writer, new QuestionStartToken("Are there ", IndexedToken.PLURAL, QuestionStartToken.YESNO, false));        
    }

    private static void indexConstraintPrefixes(IndexWriter writer) throws Exception {
        addElement(writer, new ConstraintPrefixToken("having", true));
        addElement(writer, new ConstraintPrefixToken("with", true));
    }

    private static void indexOperators(IndexWriter writer) throws Exception {
        addElement(writer, new DirectBinaryOperatorToken("equal to", "=", true));
        addElement(writer, new DirectBinaryOperatorToken("greater than", ">", true));
        addElement(writer, new DirectBinaryOperatorToken("less than", "<", true));
        addElement(writer, new DirectBinaryOperatorToken("different than", "!=", true));
        addElement(writer, new DirectBinaryOperatorToken("=", "=", false));
        addElement(writer, new DirectBinaryOperatorToken(">", ">", false));
        addElement(writer, new DirectBinaryOperatorToken("<", "<", false));
        addElement(writer, new DirectBinaryOperatorToken(">=", ">=", false));
        addElement(writer, new DirectBinaryOperatorToken("<=", "<=", false));
        addElement(writer, new DirectBinaryOperatorToken("<>", "!=", false));
        addElement(writer, new DirectBinaryOperatorToken("with year equal to", "year=", false));
        addElement(writer, new DirectBinaryOperatorToken("with year greater than", "year>", false));
        addElement(writer, new DirectBinaryOperatorToken("with year less than", "year<", false));
        addElement(writer, new DirectBinaryOperatorToken("with month equal to", "month=", false));
        addElement(writer, new IndirectBinaryOperatorToken("the same as that of", "=", false));
        addElement(writer, new IndirectBinaryOperatorToken("equal to that of", "=", false));
        addElement(writer, new IndirectBinaryOperatorToken("greater than that of", ">", false));
        addElement(writer, new IndirectBinaryOperatorToken("less than that of", "<", false));
        addElement(writer, new IndirectBinaryOperatorToken("different than that of", "!=", false));
        addElement(writer, new UnaryOperatorToken("with any", "exists", false));
        addElement(writer, new UnaryOperatorToken("with some", "exists", false));
        addElement(writer, new UnaryOperatorToken("having some", "exists", false));
        addElement(writer, new UnaryOperatorToken("without any", "not exists", false));
        addElement(writer, new UnaryOperatorToken("without specified", "not exists", false));
    }

    private static void indexPossessiveAdjective(IndexWriter writer) throws Exception {
        addElement(writer, new PossessiveDeterminerToken("its", IndexedToken.SINGULAR));
        addElement(writer, new PossessiveDeterminerToken("her", IndexedToken.SINGULAR));
        addElement(writer, new PossessiveDeterminerToken("his", IndexedToken.SINGULAR));
        addElement(writer, new PossessiveDeterminerToken("their", IndexedToken.PLURAL));
    }

    private HashSet<String> getAdmissableLiterals(String[] rangeOfAttributes) {
        HashSet<String> admissableLiterals = new HashSet<>();
        if (rangeOfAttributes == null) { //context rules where disabled
            admissableLiterals.add(DATE);
            admissableLiterals.add(STRING);
            admissableLiterals.add(DOUBLE);
        } else {
            for (String rangeOfAttribute : rangeOfAttributes) {
                AttributeToken ae = getAttributeByUri(rangeOfAttribute);
                if (ae.hasBasicTypeRange(DATE)) {
                    admissableLiterals.add(DATE);
                }
                if (ae.hasBasicTypeRange(STRING)) {
                    admissableLiterals.add(STRING);
                }
                if (ae.hasBasicTypeRange(DOUBLE)) {
                    admissableLiterals.add(DOUBLE);
                }
            }
        }
        return admissableLiterals;
    }

    public ArrayList<LiteralToken> getLiteralElements(String search, String[] rangeOfAttributes) {
        ArrayList<LiteralToken> res = new ArrayList<>();
        HashSet<String> admissableLiterals = getAdmissableLiterals(rangeOfAttributes);
        if (admissableLiterals.contains(DATE)) {
            try {
                res.add(new LiteralDateToken(search));
            } catch (Exception e) {
            }
        }
        if (admissableLiterals.contains(DOUBLE)) {
            try {
                res.add(new LiteralNumericToken(search));
            } catch (Exception e) {
            }
            try {
                res.add(new LiteralPercentageToken(search));
            } catch (Exception e) {
            }
        }
        if (admissableLiterals.contains(STRING) || admissableLiterals.contains(DATE)) {
            try {
                if (search.startsWith("\"")) {
                    if (search.endsWith("\"") && search.length()>1) {
                        res.add(new LiteralStringToken(search));
                    } else {
                        res.add(new LiteralStringToken(search+"\""));
                    }
                }
            } catch (Exception e) {
            }
        }
        return res;
    }

    public LiteralNumericToken getIntegerLiteralElement(String search) {
        try {
            return new LiteralNumericToken(search);
        } catch (Exception e) {
        }
        return null;
    }

    public ArrayList<RankOperatorToken> getRankOperatorElements(String search) {
        ArrayList<RankOperatorToken> res = new ArrayList<>();
        if (search == null) {
            return res;
        }
        search = search.trim().toLowerCase();
        if (search.equals("t") || search.equals("th") || search.equals("the")) {
            res.add(new RankOperatorToken(1, false));
            res.add(new RankOperatorToken(1, true));
            res.add(new RankOperatorToken(2, false));
            res.add(new RankOperatorToken(2, true));
            return res;
        }
        if (search.startsWith("the ")) {
            search = search.replaceFirst("the ", "").trim();
            try {
                String[] ss = search.split("\\s");
                int rank = Integer.parseInt(ss[0]);
                if (rank <= 0) {
                    return res;
                }
                if (ss.length > 1) {
                    if (ss[1].startsWith("g")) {
                        res.add(new RankOperatorToken(rank, false));
                        res.add(new RankCountOperatorToken(rank, false));
                    } else if (ss[1].startsWith("s")) {
                        res.add(new RankOperatorToken(rank, true));
                        res.add(new RankCountOperatorToken(rank, true));
                    } else {
                        res.add(new RankOperatorToken(rank, false));
                        res.add(new RankOperatorToken(rank, true));
                        res.add(new RankCountOperatorToken(rank, false));
                        res.add(new RankCountOperatorToken(rank, true));
                    }
                } else {
                    res.add(new RankOperatorToken(rank, false));
                    res.add(new RankOperatorToken(rank, true));
                    res.add(new RankCountOperatorToken(rank, false));
                    res.add(new RankCountOperatorToken(rank, true));
                }
            } catch (Exception e) {
                res.add(new RankOperatorToken(1, false));
                res.add(new RankOperatorToken(2, false));
                res.add(new RankOperatorToken(1, true));
                res.add(new RankOperatorToken(2, true));
                res.add(new RankCountOperatorToken(1, false));
                res.add(new RankCountOperatorToken(2, false));
                res.add(new RankCountOperatorToken(1, true));
                res.add(new RankCountOperatorToken(2, true));
            }
        }

        return res;
    }

    public ArrayList<TopKOperatorToken> getTopKOperatorElements(String search) {
        ArrayList<TopKOperatorToken> res = new ArrayList<>();
        if (search == null) {
            return res;
        }
        search = search.trim().toLowerCase();
        if (search.equals("o") || search.equals("on") || search.equals("one")
                || search.equals("one ") || search.equals("one o") || search.equals("one of")
                || search.equals("one of ") || search.equals("one of t")
                || search.equals("one of th") || search.equals("one of the")) {
            res.add(new TopKOperatorToken(10, false));
            res.add(new TopKOperatorToken(10, true));
            return res;
        }
        if (search.startsWith("one of the ")) {
            search = search.replaceFirst("one of the ", "").trim();
            try {
                String[] ss = search.split("\\s");
                int k = Integer.parseInt(ss[0]);
                if (k <= 0) {
                    return res;
                }
                if (ss.length > 1) {
                    if (ss[1].startsWith("g")) {
                        res.add(new TopKOperatorToken(k, false));
                    } else if (ss[1].startsWith("s")) {
                        res.add(new TopKOperatorToken(k, true));
                    } else {
                        res.add(new TopKOperatorToken(k, false));
                        res.add(new TopKOperatorToken(k, true));
                    }
                } else {
                    res.add(new TopKOperatorToken(k, false));
                    res.add(new TopKOperatorToken(k, true));
                }
            } catch (Exception e) {
                res.add(new TopKOperatorToken(10, false));
                res.add(new TopKOperatorToken(10, true));
            }
        }

        return res;
    }

    /*    
     public ArrayList<IndexedToken> getTokenElements(String search,
     String domainOfAttribute, String rangeOfAttribute,
     String[] attributeDomains,
     int maxResults, String... tokenCategories) {
     String[] da = null;
     if (domainOfAttribute != null) {
     da = new String[1];
     da[0] = domainOfAttribute;
     }
     return getTokenElements(search, da, rangeOfAttribute, attributeDomains, maxResults, tokenCategories);
     }
     */
    public ArrayList<IndexedToken> getTokenElements(String search,
            String domainsOfAttribute[], String rangesOfAttribute[],
            String[] attributeDomains,
            int maxResults, String... tokenCategories) {
        ArrayList<IndexedToken> res = new ArrayList<>();
        if (search == null) {
            search = "";
        }
        HashSet<String> admissableLiterals = getAdmissableLiterals(rangesOfAttribute);
        try {
            BooleanQuery globalQuery = new BooleanQuery();
            BooleanQuery typeQuery = new BooleanQuery();
            if (tokenCategories != null && tokenCategories.length > 0) {
                for (int i = 0; i < tokenCategories.length; i++) {
                    BooleanQuery subTypeQuery = new BooleanQuery();
                    subTypeQuery.add(new TermQuery(new Term("type", tokenCategories[i])), BooleanClause.Occur.MUST);
                    switch (tokenCategories[i]) {
                        case IndexedToken.ATTRIBUTE:
                            if (domainsOfAttribute != null && domainsOfAttribute.length > 0) {
                                BooleanQuery domainOfQuery = new BooleanQuery();
                                for (String domainOfAttribute : domainsOfAttribute) {
                                    domainOfQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(domainOfQuery, BooleanClause.Occur.MUST);
                            }
                            if (rangesOfAttribute != null && rangesOfAttribute.length > 0) {
                                BooleanQuery rangeOfQuery = new BooleanQuery();
                                for (String rangeOfAttribute : rangesOfAttribute) {
                                    rangeOfQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangeOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(rangeOfQuery, BooleanClause.Occur.MUST);
                            }
                        //if (domainsOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainsOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            //if (rangeOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangeOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            if (attributeDomains != null && attributeDomains.length > 0) {
                                BooleanQuery domainQuery = new BooleanQuery();
                                for (String attributeDomain : attributeDomains) {
                                    domainQuery.add(new TermQuery(new Term("attributeDomain", QueryParser.escape(attributeDomain))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(domainQuery, BooleanClause.Occur.MUST);
                            }
                            break;
                        case IndexedToken.ENTITY:
                            if (domainsOfAttribute != null && domainsOfAttribute.length > 0) {
                                BooleanQuery domainOfQuery = new BooleanQuery();
                                for (String domainOfAttribute : domainsOfAttribute) {
                                    domainOfQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(domainOfQuery, BooleanClause.Occur.MUST);
                            }
                            if (rangesOfAttribute != null && rangesOfAttribute.length > 0) {
                                BooleanQuery rangeOfQuery = new BooleanQuery();
                                for (String rangeOfAttribute : rangesOfAttribute) {
                                    rangeOfQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangeOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(rangeOfQuery, BooleanClause.Occur.MUST);
                            }
                        //if (domainsOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainsOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            //if (rangesOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangesOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            break;
                        case IndexedToken.CATEGORY:
                            if (domainsOfAttribute != null && domainsOfAttribute.length > 0) {
                                BooleanQuery domainOfQuery = new BooleanQuery();
                                for (String domainOfAttribute : domainsOfAttribute) {
                                    domainOfQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(domainOfQuery, BooleanClause.Occur.MUST);
                            }
                            if (rangesOfAttribute != null && rangesOfAttribute.length > 0) {
                                BooleanQuery rangeOfQuery = new BooleanQuery();
                                for (String rangeOfAttribute : rangesOfAttribute) {
                                    rangeOfQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangeOfAttribute))), BooleanClause.Occur.SHOULD);
                                }
                                subTypeQuery.add(rangeOfQuery, BooleanClause.Occur.MUST);
                            }
                        //if (domainsOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainsOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            //if (rangesOfAttribute != null) {
                            //    subTypeQuery.add(new TermQuery(new Term("rangeOfAttribute", QueryParser.escape(rangesOfAttribute))), BooleanClause.Occur.MUST);
                            //}
                            break;
                        /*
                         case IndexedToken.CONSTRAINT_PREFIX:
                         if (domainOfAttribute != null) {
                         subTypeQuery.add(new TermQuery(new Term("domainOfAttribute", QueryParser.escape(domainOfAttribute))), BooleanClause.Occur.MUST);
                         }
                         break;*/
                    }
                    typeQuery.add(subTypeQuery, BooleanClause.Occur.SHOULD);
                }
                if (tokenCategories.length > 1) {
                    //typeQuery.setMinimumNumberShouldMatch(1);
                }
                globalQuery.add(typeQuery, BooleanClause.Occur.MUST);
            }

            BooleanQuery searchQuery = new BooleanQuery();
            String[] ss = search.split(" ");
            for (String s : ss) {
                searchQuery.add(new TermQuery(new Term("label", QueryParser.escape(s))), BooleanClause.Occur.SHOULD);
            }
            //searchQuery.setMinimumNumberShouldMatch(1);
            globalQuery.add(searchQuery, BooleanClause.Occur.MUST);
            QueryParser parser = new QueryParser("", analyzer);
            try (IndexReader reader = DirectoryReader.open(directory)) {
                IndexSearcher searcher = new IndexSearcher(reader);
                String queryString = globalQuery.toString(); //I need this because the parser works differently of different search features - look at its definition
                ScoreDoc[] hits = searcher.search(parser.parse(queryString), maxResults * 5).scoreDocs;
                for (ScoreDoc r : hits) {
                    Document doc = searcher.doc(r.doc);
                    IndexedToken element = elements.get(doc.getField("id").numericValue().intValue());
                    if (element instanceof DirectBinaryOperatorToken || element instanceof IndirectBinaryOperatorToken) {
                        String op = ((OperatorToken) element).getSymbol();
                        if (op.startsWith("year") || op.startsWith("month")) {
                            if (admissableLiterals.contains(DATE)) {
                                res.add(element);
                            }
                        } else if (op.equals("=") || !admissableLiterals.isEmpty()) {
                            res.add(element);
                        }
                    } else {
                        res.add(element);
                    }
                    if (res.size() == maxResults) {
                        //break;
                    }
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(TokenIndex.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    public AttributeToken getAttributeByUri(String uri) {
        Integer id = ontologyElementsIdByUri.get(uri);
        if (id == null) {
            return null;
        }
        IndexedToken e = elements.get(id);
        if (e == null || !(e instanceof AttributeToken)) {
            return null;
        }
        return (AttributeToken) e;
    }

    public static void main(String... args) {
        //new TokenIndex().getTokenElements("gi", null, null, null, null, 20, IndexedToken.QUESTION_START);
    }

}
