/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.index.tokens;

import java.util.HashSet;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
public class EntityToken extends OntologyElementToken {

    public EntityToken(String uri, String label, boolean prefix) {
        super(uri, label, IndexedToken.SINGULAR, prefix);
    }

    @Override
    public String getText() {
        return label;
    }

    @Override
    public String getType() {
        return ENTITY;
    }

}
