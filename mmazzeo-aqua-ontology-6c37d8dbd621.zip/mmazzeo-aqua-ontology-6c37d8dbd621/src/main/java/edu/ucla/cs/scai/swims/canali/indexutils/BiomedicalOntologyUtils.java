/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.indexutils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
//In order to run this file, you must download the following file
//http://greententacle.techfak.uni-bielefeld.de/~cunger/qald/4/data/biomed_dumps.zip
//Uncompress the zip file in your working directyory, thus obtaining
//diseasome.nt, drugbank_dump.nt, and sider_dump.nt
public class BiomedicalOntologyUtils {

    String downloadedFilesPath, destinationPath;
    HashMap<String, Integer> entityIds = new HashMap<>();
    String[] entityById;
    HashSet<Integer>[] edges;
    HashSet<String> categories = new HashSet<>();
    HashSet<String> attributes = new HashSet<>();
    HashMap<String, HashSet<String>> categoryLabels = new HashMap<>();
    HashMap<String, HashSet<String>> attributeLabels = new HashMap<>();
    HashMap<String, HashSet<String>> entityLabels = new HashMap<>();
    HashMap<String, HashSet<String>> entityCategories = new HashMap<>();
    int[] sameAs;
    private static final String[] fileNames = {"diseasome.nt", "drugbank_dump.nt", "sider_dump.nt"};

    public BiomedicalOntologyUtils(String downloadedFilesPath, String destinationPath) throws Exception {
        if (!downloadedFilesPath.endsWith(File.separator)) {
            downloadedFilesPath += File.separator;
        }
        if (!destinationPath.endsWith(File.separator)) {
            destinationPath += File.separator;
        }
        this.downloadedFilesPath = downloadedFilesPath;
        this.destinationPath = destinationPath;
    }

    private void computeSameAsGroups() throws IOException {
        //load all entities and assign an id to them
        //dbpedia entites are loaded first
        String regex = "(\\s|\\t)*<(.*)>(\\s|\\t)*<(.*)>(\\s|\\t)*(<|\")(.*)(>|\")";
        Pattern p = Pattern.compile(regex);
        for (String fileName : fileNames) {
            try (
                    BufferedReader in = new BufferedReader(new FileReader(downloadedFilesPath + fileName))) {
                String l = in.readLine();
                while (l != null) {
                    Matcher m = p.matcher(l);
                    if (m.find()) {
                        String s = m.group(2);
                        if (s.startsWith("http://www.dbpedia.org") && !entityIds.containsKey(s)) {
                            entityIds.put(s, entityIds.size() + 1);
                        }
                        String v = m.group(7);
                        if (v.startsWith("http://www.dbpedia.org") && !entityIds.containsKey(v)) {
                            entityIds.put(v, entityIds.size() + 1);
                        }
                    }
                    l = in.readLine();
                }
            }
        }
        //now non-dpedia entities are loaded
        for (String fileName : fileNames) {
            try (
                    BufferedReader in = new BufferedReader(new FileReader(downloadedFilesPath + fileName))) {
                String l = in.readLine();
                while (l != null) {
                    Matcher m = p.matcher(l);
                    if (m.find()) {
                        String s = m.group(2);
                        if (!s.startsWith("http://www.dbpedia.org") && !entityIds.containsKey(s)) {
                            entityIds.put(s, entityIds.size() + 1);
                        }
                        String v = m.group(7);
                        if (!v.startsWith("http://www.dbpedia.org") && !entityIds.containsKey(v)) {
                            entityIds.put(v, entityIds.size() + 1);
                        }
                    }
                    l = in.readLine();
                }
            }
        }
        //create the edges sets        
        edges = new HashSet[entityIds.size() + 1];
        entityById = new String[entityIds.size() + 1];
        for (Map.Entry<String, Integer> e : entityIds.entrySet()) {
            entityById[e.getValue()] = e.getKey();
        }

        for (String fileName : fileNames) {
            try (
                    BufferedReader in = new BufferedReader(new FileReader(downloadedFilesPath + fileName))) {
                String l = in.readLine();
                while (l != null) {
                    Matcher m = p.matcher(l);
                    if (m.find()) {
                        String a = m.group(4);
                        if (a.equals("http://www.w3.org/2002/07/owl#sameAs")) {
                            String s = m.group(2);
                            int idS = entityIds.get(s);
                            String v = m.group(7);
                            int idV = entityIds.get(v);
                            if (edges[idS] == null) {
                                edges[idS] = new HashSet<>();
                            }
                            edges[idS].add(idV);
                            if (edges[idV] == null) {
                                edges[idV] = new HashSet<>();
                            }
                            edges[idV].add(idS);
                        } else if (a.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")) {
                            String s = m.group(2);
                            String v = m.group(7);
                            if (v.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#Property")) {
                                attributes.add(s);
                            } else if (v.equals("http://www.w3.org/2000/01/rdf-schema#Class")) {
                                categories.add(s);
                            }
                        }
                    }
                    l = in.readLine();
                }
            }
        }
        sameAs = new int[entityIds.size() + 1];

        int i = 1;
        while (i < sameAs.length) {

            LinkedList<Integer> q = new LinkedList<>();
            q.addLast(i);
            while (!q.isEmpty()) {
                int j = q.removeFirst();
                if (sameAs[j] != 0) {
                    if (sameAs[j] != i) {
                        System.out.println("Error");
                        System.exit(0);
                    }
                } else {
                    sameAs[j] = i;
                    if (edges[j] != null) {
                        for (int k : edges[j]) {
                            q.addLast(k);
                        }
                    }
                }
            }

            i++;
            while (i < sameAs.length && sameAs[i] != 0) {
                i++;
            }
        }
    }

    private void loadLabelsAndCategories() throws IOException {
        String regex = "(\\s|\\t)*<(.*)>(\\s|\\t)*<(.*)>(\\s|\\t)*(<|\")(.*)(>|\")";
        Pattern p = Pattern.compile(regex);
        for (String fileName : fileNames) {
            try (
                    BufferedReader in = new BufferedReader(new FileReader(downloadedFilesPath + fileName))) {
                String l = in.readLine();
                while (l != null) {
                    Matcher m = p.matcher(l);
                    if (m.find()) {
                        String a = m.group(4);
                        String s = m.group(2);
                        String v = m.group(7);
                        if (a.equals("http://www.w3.org/2000/01/rdf-schema#label")) {
                            if (categories.contains(s)) {
                                HashSet<String> labels = categoryLabels.get(s);
                                if (labels == null) {
                                    labels = new HashSet<>();
                                    categoryLabels.put(s, labels);
                                }
                                labels.add(v);
                            } else if (attributes.contains(s)) {
                                HashSet<String> labels = attributeLabels.get(s);
                                if (labels == null) {
                                    labels = new HashSet<>();
                                    attributeLabels.put(s, labels);
                                }
                                labels.add(v);
                            } else {
                                int eId = entityIds.get(s);
                                int eId2 = sameAs[eId];
                                s = entityById[eId2];
                                HashSet<String> labels = entityLabels.get(s);
                                if (labels == null) {
                                    labels = new HashSet<>();
                                    entityLabels.put(s, labels);
                                }
                                labels.add(v);
                            }
                        } else if (a.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")) {
                            int eId = entityIds.get(s);
                            int eId2 = sameAs[eId];
                            s = entityById[eId2];
                            HashSet<String> categories = entityCategories.get(s);
                            if (categories == null) {
                                categories = new HashSet<>();
                                entityCategories.put(s, categories);
                            }
                            categories.add(v);
                        }
                    }
                    l = in.readLine();
                }
            }
        }
    }

    private void createCategoryParentsFile() throws IOException { //it just creates an empty file
        try (
                PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "category_parents"))) {
        }
    }

    private void createCategoryLabelsFile() throws IOException { //it just creates an empty file
        for (String cat : categories) {
            System.out.println(cat);
        }
        try (
                PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "category_labels"))) {
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/targets\ttarget");
            out.println("http://www4.wiwiss.fu-berlin.de/diseasome/resource/diseasome/genes\tgene");
            out.println("http://www4.wiwiss.fu-berlin.de/sider/resource/sider/drugs\tdrug");
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/vocab/resource/class/Offer\toffer");
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/references\treference");
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/drugs\tdrug");
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/drug_interactions\tdrug interaction");
            out.println("http://www4.wiwiss.fu-berlin.de/sider/resource/sider/side_effects\tside effect");
            out.println("http://www4.wiwiss.fu-berlin.de/diseasome/resource/diseasome/diseases\tdisease");
            out.println("http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/enzymes\tenzyme");
        }
    }

    private void createAttributeLabelsFile() throws IOException { //it just creates an empty file
        try (
                PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "attribute_labels"))) {
            for (String a : attributes) {
                if (attributeLabels.containsKey(a)) {
                    for (String l : attributeLabels.get(a)) {
                        out.println(a + "\t" + l);
                    }
                } else {
                    String[] s = a.split("\\/");
                    String l = s[s.length - 1].replaceAll("\\_", " ");
                    out.println(a + "\t" + l);
                }
            }
        }
    }

    private void createEntityLabelsFile() throws IOException { //it just creates an empty file
        try (
                PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "entity_labels"))) {
            for (Map.Entry<String, HashSet<String>> e : entityLabels.entrySet()) {
                for (String l : e.getValue()) {
                    out.println(e.getKey() + "\t" + l);
                }
            }
        }
    }

    private void createEntityCategoriesFile() throws IOException { //it just creates an empty file
        try (
                PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "entity_categories"))) {
            for (Map.Entry<String, HashSet<String>> e : entityCategories.entrySet()) {
                for (String l : e.getValue()) {
                    out.println(e.getKey() + "\t" + l);
                }
            }
        }
    }

    private void createTriplesFile() throws IOException {
        attributes.remove("http://www.w3.org/2000/01/rdf-schema#label");
        attributes.remove("http://www.w3.org/2000/01/rdf-schema#seeAlso");
        attributes.remove("http://www.w3.org/2002/07/owl#sameAs");
        attributes.remove("http://www.w3.org/2002/07/owl#equivalentClass");
        attributes.remove("http://www.w3.org/2002/07/owl#equivalentProperty");
        String regex = "(\\s|\\t)*<(.*)>(\\s|\\t)+<(.*)>(\\s|\\t)+(.*)(\\s|\\t)+\\.$";
        Pattern p = Pattern.compile(regex);
        try (PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "triples"))) {
            for (String fileName : fileNames) {
                try (
                        BufferedReader in = new BufferedReader(new FileReader(downloadedFilesPath + fileName))) {
                    String l = in.readLine();
                    while (l != null) {
                        Matcher m = p.matcher(l);
                        if (m.find()) {
                            String a = m.group(4);
                            if (attributes.contains(a)) {
                                String s = m.group(2);
                                String v = m.group(6).trim().replaceAll("\\t", "");
                                Integer eId = entityIds.get(s);
                                if (eId==null) {
                                    continue;
                                }
                                int eId2 = sameAs[eId];
                                s = entityById[eId2];
                                out.print("<" + s + "> <" + a + "> ");
                                if (v.startsWith("<")) {
                                    v=v.substring(1, v.length()-1);
                                    int vId = entityIds.get(v);
                                    int vId2 = sameAs[vId];
                                    v = entityById[vId2];
                                    out.println("<" + v + "> .");
                                } else {
                                    out.println(v+" .");
                                }                                
                            } else {
                                System.out.println("Dropped " + l);
                            }
                        } else {
                            System.out.println("Could not recognize " + l);
                        }
                        l = in.readLine();
                    }
                }
            }
        }
    }

    public static void main(String... args) throws Exception {
        long start = System.currentTimeMillis();
        System.out.println("Started at " + new Date());
        BiomedicalOntologyUtils biokb = new BiomedicalOntologyUtils("/home/massimo/aquawd/biomedical-downloaded-files/", "/home/massimo/aquawd/biomedical-ontology-files/");
        biokb.computeSameAsGroups();
        biokb.createCategoryParentsFile();
        biokb.loadLabelsAndCategories();
        biokb.createCategoryLabelsFile();
        biokb.createAttributeLabelsFile();
        biokb.createEntityLabelsFile();
        biokb.createEntityCategoriesFile();
        biokb.createTriplesFile();
        biokb.createBasicTypesLiteralTypesFile();
        System.out.println("Ended at " + new Date());
        long time = System.currentTimeMillis() - start;
        long sec = time / 1000;
        System.out.println("The process took " + (sec / 60) + "'" + (sec % 60) + "." + (time % 1000) + "\"");
    }

    public void createBasicTypesLiteralTypesFile() throws Exception {
        System.out.println("Saving basic types");
        try (PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "basic_types_literal_types", false), true)) {
            out.println("http://dbpedia.org/datatype/centimetre\tDouble");
            out.println("http://dbpedia.org/datatype/cubicCentimetre\tDouble");
            out.println("http://dbpedia.org/datatype/cubicKilometre\tDouble");
            out.println("http://dbpedia.org/datatype/cubicMetre\tDouble");
            out.println("http://dbpedia.org/datatype/cubicMetrePerSecond\tDouble");
            out.println("http://dbpedia.org/datatype/day\tDouble");
            out.println("http://dbpedia.org/datatype/gramPerKilometre\tDouble");
            out.println("http://dbpedia.org/datatype/hour\tDouble");
            out.println("http://dbpedia.org/datatype/inhabitantsPerSquareKilometre\tDouble");
            out.println("http://dbpedia.org/datatype/kelvin\tDouble");
            out.println("http://dbpedia.org/datatype/kilogram\tDouble");
            out.println("http://dbpedia.org/datatype/kilogramPerCubicMetre\tDouble");
            out.println("http://dbpedia.org/datatype/kilometre\tDouble");
            out.println("http://dbpedia.org/datatype/kilometrePerHour\tDouble");
            out.println("http://dbpedia.org/datatype/kilometrePerSecond\tDouble");
            out.println("http://dbpedia.org/datatype/kilowatt\tDouble");
            out.println("http://dbpedia.org/datatype/litre\tDouble");
            out.println("http://dbpedia.org/datatype/megabyte\tDouble");
            out.println("http://dbpedia.org/datatype/metre\tDouble");
            out.println("http://dbpedia.org/datatype/millimetre\tDouble");
            out.println("http://dbpedia.org/datatype/minute\tDouble");
            out.println("http://dbpedia.org/datatype/newtonMetre\tDouble");
            out.println("http://dbpedia.org/datatype/second\tDouble");
            out.println("http://dbpedia.org/datatype/squareKilometre\tDouble");
            out.println("http://dbpedia.org/datatype/squareMetre\tDouble");
            out.println("http://www.w3.org/1999/02/22-rdf-syntax-ns#langString\tString");
            out.println("http://dbpedia.org/datatype/usDollar\tDouble");
            out.println("http://dbpedia.org/datatype/euro\tDouble");
            out.println("http://dbpedia.org/datatype/poundSterling\tDouble");
            out.println("http://dbpedia.org/datatype/swedishKrona\tDouble");
            out.println("http://dbpedia.org/datatype/philippinePeso\tDouble");
            out.println("http://dbpedia.org/datatype/singaporeDollar\tDouble");
            out.println("http://dbpedia.org/datatype/indianRupee\tDouble");
            out.println("http://dbpedia.org/datatype/mauritianRupee\tDouble");
            out.println("http://dbpedia.org/datatype/canadianDollar\tDouble");
            out.println("http://dbpedia.org/datatype/hongKongDollar\tDouble");
            out.println("http://dbpedia.org/datatype/zambianKwacha\tDouble");
            out.println("http://dbpedia.org/datatype/moroccanDirham\tDouble");
            out.println("http://dbpedia.org/datatype/ghanaianCedi\tDouble");
            out.println("http://dbpedia.org/datatype/peruvianNuevoSol\tDouble");
            out.println("http://dbpedia.org/datatype/thaiBaht\tDouble");
            out.println("http://dbpedia.org/datatype/nicaraguanCórdoba\tDouble");
            out.println("http://dbpedia.org/datatype/malaysianRinggit\tDouble");
            out.println("http://dbpedia.org/datatype/unitedArabEmiratesDirham\tDouble");
            out.println("http://dbpedia.org/datatype/ethiopianBirr\tDouble");
            out.println("http://dbpedia.org/datatype/egyptianPound\tDouble");
            out.println("http://dbpedia.org/datatype/tanzanianShilling\tDouble");
            out.println("http://dbpedia.org/datatype/azerbaijaniManat\tDouble");
            out.println("http://dbpedia.org/datatype/indonesianRupiah\tDouble");
            out.println("http://dbpedia.org/datatype/botswanaPula\tDouble");
            out.println("http://dbpedia.org/datatype/bangladeshiTaka\tDouble");
            out.println("http://dbpedia.org/datatype/czechKoruna\tDouble");
            out.println("http://dbpedia.org/datatype/belizeDollar\tDouble");
            out.println("http://dbpedia.org/datatype/ukrainianHryvnia\tDouble");
            out.println("http://dbpedia.org/datatype/bulgarianLev\tDouble");
            out.println("http://dbpedia.org/datatype/icelandKrona\tDouble");
            out.println("http://dbpedia.org/datatype/sriLankanRupee\tDouble");
            out.println("http://dbpedia.org/datatype/armenianDram\tDouble");
            out.println("http://dbpedia.org/datatype/pakistaniRupee\tDouble");
            out.println("http://dbpedia.org/datatype/southAfricanRand\tDouble");
            out.println("http://dbpedia.org/datatype/romanianNewLeu\tDouble");
            out.println("http://dbpedia.org/datatype/colombianPeso\tDouble");
            out.println("http://dbpedia.org/datatype/russianRouble\tDouble");
            out.println("http://dbpedia.org/datatype/algerianDinar\tDouble");
            out.println("http://dbpedia.org/datatype/sierraLeoneanLeone\tDouble");
            out.println("http://dbpedia.org/datatype/netherlandsAntilleanGuilder\tDouble");
            out.println("http://dbpedia.org/datatype/nigerianNaira\tDouble");
            out.println("http://dbpedia.org/datatype/hungarianForint\tDouble");
            out.println("http://dbpedia.org/datatype/estonianKroon\tDouble");
            out.println("http://dbpedia.org/datatype/georgianLari\tDouble");
            out.println("http://dbpedia.org/datatype/gambianDalasi\tDouble");
            out.println("http://dbpedia.org/datatype/gibraltarPound\tDouble");
            out.println("http://dbpedia.org/datatype/kuwaitiDinar\tDouble");
            out.println("http://dbpedia.org/datatype/brazilianReal\tDouble");
            out.println("http://dbpedia.org/datatype/maldivianRufiyaa\tDouble");
            out.println("http://dbpedia.org/datatype/jordanianDinar\tDouble");
            out.println("http://dbpedia.org/datatype/israeliNewSheqel\tDouble");
            out.println("http://dbpedia.org/datatype/saudiRiyal\tDouble");
            out.println("http://dbpedia.org/datatype/serbianDinar\tDouble");
            out.println("http://dbpedia.org/datatype/iranianRial\tDouble");
            out.println("http://dbpedia.org/datatype/omaniRial\tDouble");
            out.println("http://dbpedia.org/datatype/nepaleseRupee\tDouble");
            out.println("http://dbpedia.org/datatype/argentinePeso\tDouble");
            out.println("http://dbpedia.org/datatype/honduranLempira\tDouble");
            out.println("http://dbpedia.org/datatype/papuaNewGuineanKina\tDouble");
            out.println("http://dbpedia.org/datatype/qatariRial\tDouble");
            out.println("http://dbpedia.org/datatype/moldovanLeu\tDouble");
            out.println("http://dbpedia.org/datatype/bosniaAndHerzegovinaConvertibleMarks\tDouble");
            out.println("http://dbpedia.org/datatype/kazakhstaniTenge\tDouble");
            out.println("http://dbpedia.org/datatype/malawianKwacha\tDouble");
            out.println("http://dbpedia.org/datatype/newTaiwanDollar\tDouble");
            out.println("http://dbpedia.org/datatype/chileanPeso\tDouble");
            out.println("http://dbpedia.org/datatype/southKoreanWon\tDouble");
            out.println("http://dbpedia.org/datatype/bahrainiDinar\tDouble");
            out.println("http://dbpedia.org/datatype/latvianLats\tDouble");
            out.println("http://dbpedia.org/datatype/jamaicanDollar\tDouble");
            out.println("http://dbpedia.org/datatype/namibianDollar\tDouble");
            out.println("http://dbpedia.org/datatype/latvianLats\tDouble");
            out.println("http://dbpedia.org/datatype/turkishLira\tDouble");
            out.println("http://dbpedia.org/datatype/danishKrone\tDouble");
            out.println("http://dbpedia.org/datatype/norwegianKrone\tDouble");
            out.println("http://dbpedia.org/datatype/kenyanShilling\tDouble");
            out.println("http://dbpedia.org/datatype/renminbi\tDouble");
            out.println("http://dbpedia.org/datatype/polishZłoty\tDouble");
            out.println("http://dbpedia.org/datatype/ugandaShilling\tDouble");
            out.println("http://dbpedia.org/datatype/japaneseYen\tDouble");
            out.println("http://dbpedia.org/datatype/newZealandDollar\tDouble");
            out.println("http://dbpedia.org/datatype/rwandaFranc\tDouble");
            out.println("http://dbpedia.org/datatype/swissFranc\tDouble");
            out.println("http://dbpedia.org/datatype/australianDollar\tDouble");
            out.println("http://dbpedia.org/datatype/mexicanPeso\tDouble");
            out.println("http://dbpedia.org/datatype/lithuanianLitas\tDouble");
            out.println("http://dbpedia.org/datatype/croatianKuna\tDouble");
            out.println("http://dbpedia.org/datatype/engineConfiguration\tString");
            out.println("http://dbpedia.org/datatype/fuelType\tString");
            out.println("http://dbpedia.org/datatype/valvetrain\tString");
            out.println("http://dbpedia.org/datatype/rod\tDouble");
            out.println("http://dbpedia.org/datatype/degreeRankine\tDouble");
            out.println("http://dbpedia.org/datatype/stone\tDouble");
            out.println("http://dbpedia.org/datatype/perCent\tDouble");
            out.println("http://dbpedia.org/datatype/gram\tDouble");
            out.println("http://dbpedia.org/datatype/pond\tDouble");
            out.println("http://dbpedia.org/datatype/inch\tDouble");
            out.println("http://dbpedia.org/datatype/pound\tDouble");
            out.println("http://dbpedia.org/datatype/megahertz\tDouble");
            out.println("http://dbpedia.org/datatype/gramPerCubicCentimetre\tDouble");
            out.println("http://dbpedia.org/datatype/micrometre\tDouble");
            out.println("http://dbpedia.org/datatype/tonne\tDouble");
            out.println("http://dbpedia.org/datatype/squareFoot\tDouble");
            out.println("http://dbpedia.org/datatype/nanometre\tDouble");
            out.println("http://dbpedia.org/datatype/foot\tDouble");
            out.println("http://dbpedia.org/datatype/gigalitre\tDouble");
            out.println("http://dbpedia.org/datatype/acre\tDouble");
            out.println("http://dbpedia.org/datatype/horsepower\tDouble");
            out.println("http://dbpedia.org/datatype/milePerHour\tDouble");
            out.println("http://dbpedia.org/datatype/mile\tDouble");
            out.println("http://dbpedia.org/datatype/nautialMile\tDouble");
            out.println("http://dbpedia.org/datatype/footPerMinute\tDouble");
            out.println("http://dbpedia.org/datatype/metrePerSecond\tDouble");
            out.println("http://dbpedia.org/datatype/ampere\tDouble");
            out.println("http://dbpedia.org/datatype/degreeCelsius\tDouble");
            out.println("http://dbpedia.org/datatype/astronomicalUnit\tDouble");
            out.println("http://dbpedia.org/datatype/millibar\tDouble");
            out.println("http://dbpedia.org/datatype/milligram\tDouble");
            out.println("http://dbpedia.org/datatype/byte\tDouble");
            out.println("http://dbpedia.org/datatype/degreeFahrenheit\tDouble");
            out.println("http://dbpedia.org/datatype/decimetre\tDouble");
            out.println("http://dbpedia.org/datatype/watt\tDouble");
            out.println("http://dbpedia.org/datatype/knot\tDouble");
            out.println("http://dbpedia.org/datatype/perMil\tDouble");
            out.println("http://dbpedia.org/datatype/megawatt\tDouble");
            out.println("http://dbpedia.org/datatype/kilowattHour\tDouble");
            out.println("http://dbpedia.org/datatype/kilopascal\tDouble");
            out.println("http://dbpedia.org/datatype/kilobyte\tDouble");
            out.println("http://dbpedia.org/datatype/pferdestaerke\tDouble");
            out.println("http://dbpedia.org/datatype/footPerSecond\tDouble");
            out.println("http://dbpedia.org/datatype/gigawattHour\tDouble");
            out.println("http://dbpedia.org/datatype/bit\tDouble");
            out.println("http://dbpedia.org/datatype/myanmaKyat\tDouble");
            out.println("http://dbpedia.org/datatype/tonganPaanga\tDouble");
            out.println("http://dbpedia.org/datatype/millilitre\tDouble");
            out.println("http://dbpedia.org/datatype/nanosecond\tDouble");
            out.println("http://dbpedia.org/datatype/bar\tDouble");
            out.println("http://dbpedia.org/datatype/gigabyte\tDouble");
            out.println("http://dbpedia.org/datatype/bahamianDollar\tDouble");
            out.println("http://dbpedia.org/datatype/volt\tDouble");
            out.println("http://dbpedia.org/datatype/kilolightYear\tDouble");
            out.println("http://dbpedia.org/datatype/pascal\tDouble");
            out.println("http://dbpedia.org/datatype/gigametre\tDouble");
            out.println("http://dbpedia.org/datatype/terabyte\tDouble");
            out.println("http://dbpedia.org/datatype/kilogramForce\tDouble");
            out.println("http://dbpedia.org/datatype/hectare\tDouble");
            out.println("http://dbpedia.org/datatype/megalitre\tDouble");
            out.println("http://dbpedia.org/datatype/gigawatt\tDouble");
            out.println("http://dbpedia.org/datatype/terawattHour\tDouble");
            out.println("http://dbpedia.org/datatype/kilohertz\tDouble");
            out.println("http://dbpedia.org/datatype/hertz\tDouble");
            out.println("http://dbpedia.org/datatype/newton\tDouble");
            out.println("http://dbpedia.org/datatype/meganewton\tDouble");
            out.println("http://dbpedia.org/datatype/lightYear\tDouble");
            out.println("http://dbpedia.org/datatype/megabit\tDouble");
            out.println("http://dbpedia.org/datatype/cubicInch\tDouble");
            out.println("http://dbpedia.org/datatype/squareMile\tDouble");
            out.println("http://dbpedia.org/datatype/cubicFeetPerSecond\tDouble");
            out.println("http://dbpedia.org/datatype/joule\tDouble");
            out.println("http://dbpedia.org/datatype/seychellesRupee\tDouble");
            out.println("http://dbpedia.org/datatype/yard\tDouble");
            out.println("http://dbpedia.org/datatype/squareCentimetre\tDouble");
            out.println("http://dbpedia.org/datatype/microlitre\tDouble");
            out.println("http://dbpedia.org/datatype/calorie\tDouble");
            out.println("http://dbpedia.org/datatype/cubicHectometre\tDouble");
            out.println("http://dbpedia.org/datatype/brakeHorsepower\tDouble");
            out.println("http://dbpedia.org/datatype/gramPerMillilitre\tDouble");
            out.println("http://dbpedia.org/datatype/milliwatt\tDouble");
            out.println("http://dbpedia.org/datatype/poundPerSquareInch\tDouble");
            out.println("http://dbpedia.org/datatype/hectolitre\tDouble");
            out.println("http://dbpedia.org/datatype/millipond\tDouble");
            out.println("http://dbpedia.org/datatype/saintHelenaPound\tDouble");
            out.println("http://dbpedia.org/datatype/ounce\tDouble");
            out.println("http://dbpedia.org/datatype/bermudianDollar\tDouble");
            out.println("http://dbpedia.org/datatype/kilocalorie\tDouble");
            out.println("http://dbpedia.org/datatype/hectopascal\tDouble");
            out.println("http://dbpedia.org/datatype/millihertz\tDouble");
            out.println("http://dbpedia.org/datatype/kilovolt\tDouble");
            out.println("http://dbpedia.org/datatype/kilojoule\tDouble");
            out.println("http://dbpedia.org/datatype/grain\tDouble");
            out.println("http://dbpedia.org/datatype/albanianLek\tDouble");
            out.println("http://dbpedia.org/datatype/milliampere\tDouble");
            out.println("http://dbpedia.org/datatype/cubicMillimetre\tDouble");
            out.println("http://dbpedia.org/datatype/usGallon\tDouble");
            out.println("http://dbpedia.org/datatype/cubicFoot\tDouble");
            out.println("http://dbpedia.org/datatype/gigahertz\tDouble");
            out.println("http://dbpedia.org/datatype/centilitre\tDouble");
            out.println("http://dbpedia.org/datatype/decilitre\tDouble");
            out.println("http://dbpedia.org/datatype/tonneForce\tDouble");
            out.println("http://dbpedia.org/datatype/sãoToméAndPríncipeDobra\tDouble");
            out.println("http://dbpedia.org/datatype/eritreanNakfa\tDouble");
            out.println("http://dbpedia.org/datatype/megapond\tDouble");
            out.println("http://dbpedia.org/datatype/megapascal\tDouble");
            out.println("http://dbpedia.org/datatype/giganewton\tDouble");
            out.println("http://dbpedia.org/datatype/megavolt\tDouble");
            out.println("http://dbpedia.org/datatype/kilopond\tDouble");
            out.println("http://dbpedia.org/datatype/bolivianBoliviano\tDouble");
            out.println("http://dbpedia.org/datatype/mongolianTögrög\tDouble");
            out.println("http://dbpedia.org/datatype/furlong\tDouble");
            out.println("http://dbpedia.org/datatype/belarussianRuble\tDouble");
            out.println("http://dbpedia.org/datatype/lebanesePound\tDouble");
            out.println("http://dbpedia.org/datatype/laoKip\tDouble");
            out.println("http://dbpedia.org/datatype/guineaFranc\tDouble");
            out.println("http://dbpedia.org/datatype/gramForce\tDouble");
            out.println("http://dbpedia.org/datatype/poundFoot\tDouble");
            out.println("http://dbpedia.org/datatype/cubicYard\tDouble");
            out.println("http://dbpedia.org/datatype/sudanesePound\tDouble");
            out.println("http://dbpedia.org/datatype/somaliShilling\tDouble");
            out.println("http://dbpedia.org/datatype/syrianPound\tDouble");
            out.println("http://dbpedia.org/datatype/megawattHour\tDouble");
            out.println("http://dbpedia.org/datatype/dominicanPeso\tDouble");
            out.println("http://dbpedia.org/datatype/caymanIslandsDollar\tDouble");
            out.println("http://dbpedia.org/datatype/microsecond\tDouble");
            out.println("http://dbpedia.org/datatype/capeVerdeEscudo\tDouble");
            out.println("http://dbpedia.org/datatype/imperialGallon\tDouble");
            out.println("http://dbpedia.org/datatype/squareHectometre\tDouble");
            out.println("http://dbpedia.org/datatype/squareDecimetre\tDouble");
            out.println("http://dbpedia.org/datatype/kilolitre\tDouble");
            out.println("http://dbpedia.org/datatype/hectometre\tDouble");
            out.println("http://dbpedia.org/datatype/standardAtmosphere\tDouble");
            out.println("http://dbpedia.org/datatype/zimbabweanDollar\tDouble");
            out.println("http://dbpedia.org/datatype/congoleseFranc\tDouble");
            out.println("http://dbpedia.org/datatype/arubanGuilder\tDouble");
            out.println("http://dbpedia.org/datatype/kilometresPerLitre\tDouble");
            out.println("http://dbpedia.org/datatype/cubicDecimetre\tDouble");
            out.println("http://dbpedia.org/datatype/venezuelanBolívar\tDouble");
            out.println("http://dbpedia.org/datatype/wattHour\tDouble");
            out.println("http://dbpedia.org/datatype/trinidadAndTobagoDollar\tDouble");
            out.println("http://dbpedia.org/datatype/erg\tDouble");
            out.println("http://dbpedia.org/datatype/fijiDollar\tDouble");
            out.println("http://dbpedia.org/datatype/malagasyAriary\tDouble");
            out.println("http://dbpedia.org/datatype/bhutaneseNgultrum\tDouble");
            out.println("http://dbpedia.org/datatype/kiloampere\tDouble");
            out.println("http://dbpedia.org/datatype/squareMillimetre\tDouble");
            out.println("http://dbpedia.org/datatype/imperialBarrelOil\tDouble");
            out.println("http://dbpedia.org/datatype/macanesePataca\tDouble");
            out.println("http://dbpedia.org/datatype/samoanTala\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#gMonthDay\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#anyURI\tString");
            out.println("http://www.w3.org/2001/XMLSchema#boolean\tBoolean");
            out.println("http://www.w3.org/2001/XMLSchema#date\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#dateTime\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#double\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#float\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#gYear\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#gYearMonth\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#integer\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#nonNegativeInteger\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#positiveInteger\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#string\tString");
        }
    }

}
