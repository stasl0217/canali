/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.index.tokens;

import java.io.Serializable;
import java.util.HashSet;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
public abstract class OntologyElementToken extends IndexedToken {

    public String uri;
    public String label;

    public OntologyElementToken(String uri, String label, int multiplicity, boolean prefix) {
        super(multiplicity, prefix);
        this.uri = uri;
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public String getUri() {
        return uri;
    }

}
