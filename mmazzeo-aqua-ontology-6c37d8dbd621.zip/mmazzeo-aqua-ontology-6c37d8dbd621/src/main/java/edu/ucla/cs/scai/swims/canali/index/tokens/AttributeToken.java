/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.index.tokens;

import java.util.HashSet;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
public class AttributeToken extends OntologyElementToken {

    HashSet<String> basicTypeRanges = new HashSet<>();
    HashSet<String> attributeAndCategoryDomain = new HashSet<>();
    boolean hasOutAttributes;
    boolean hasLiteralRange;
    int form;

    public static final int VERBAL = 1, NOMINAL = 2;

    public AttributeToken(String uri, String label, int multiplicity, int form, boolean hasOutAttributes, boolean hasLiteralRange, boolean prefix) {
        super(uri, label, multiplicity, prefix);
        this.form = form;
        this.hasOutAttributes = hasOutAttributes;
        this.hasLiteralRange = hasLiteralRange;
    }
    
    public int getForm() {
        return form;
    }

    @Override
    public String getType() {
        return ATTRIBUTE;
    }

    @Override
    public String getText() {
        return label.toLowerCase();
    }

    public boolean addBasicTypeRange(String s) {
        return basicTypeRanges.add(s);
    }

    public boolean addBasicTypeRanges(HashSet<String> s) {
        return basicTypeRanges.addAll(s);
    }

    public boolean hasBasicTypeRange(String s) {
        return basicTypeRanges.contains(s);
    }

    public boolean hasOutAttributes() {
        return hasOutAttributes;
    }

    public boolean hasLiteralRange() {
        return hasLiteralRange;
    }

    public boolean hasAttributeOrCategoryDomain(String uri) {
        return attributeAndCategoryDomain.contains(uri);
    }

    public boolean addAttributeOrCategoryDomain(String uri) {
        return attributeAndCategoryDomain.add(uri);
    }

    public void setAttributeAndCategoryDomain(HashSet<String> attributeAndCategoryDomain) {
        this.attributeAndCategoryDomain = attributeAndCategoryDomain;
    }
}
