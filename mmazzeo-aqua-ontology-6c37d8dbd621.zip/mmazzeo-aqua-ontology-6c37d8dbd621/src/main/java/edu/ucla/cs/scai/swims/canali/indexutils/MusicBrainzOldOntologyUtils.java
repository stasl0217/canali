/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.scai.swims.canali.indexutils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import org.semanticweb.yars.nx.Literal;
import org.semanticweb.yars.nx.Node;
import org.semanticweb.yars.nx.Resource;
import org.semanticweb.yars.nx.parser.NxParser;

/**
 *
 * @author Giuseppe M. Mazzeo <mazzeo@cs.ucla.edu>
 */
//In order to run this file, you must download the following files
//http://greententacle.techfak.uni-bielefeld.de/~cunger/download/musicbrainz.owl
//http://greententacle.techfak.uni-bielefeld.de/~cunger/download/musicbrainz.tgz
//Uncompress the tgz file in your working directyory
//then convert rdf filte to nt using the utility http://www.l3s.de/~minack/rdf2rdf/
public class MusicBrainzOldOntologyUtils {

    String downloadedFilesPath, destinationPath;
    File[] files;
    HashMap<String, HashSet<String>> attributeLabels = new HashMap<>();
    HashMap<String, HashSet<String>> categoryLabels = new HashMap<>();
    HashMap<String, HashSet<String>> categoryParents = new HashMap<>();
    HashSet<String> attributes = new HashSet<>();
    HashSet<String> categories = new HashSet<>();

    public MusicBrainzOldOntologyUtils(String downloadedFilesPath, String destinationPath) throws Exception {
        if (!downloadedFilesPath.endsWith(File.separator)) {
            downloadedFilesPath += File.separator;
        }
        if (!destinationPath.endsWith(File.separator)) {
            destinationPath += File.separator;
        }
        this.downloadedFilesPath = downloadedFilesPath;
        this.destinationPath = destinationPath;
        File folder = new File(downloadedFilesPath);
        files = folder.listFiles();
        Arrays.sort(files);
        System.out.println("Loading musicbrainz ontology");
        readHashMapFromFile("category_parents", categoryParents, "http://www.w3.org/2002/07/owl#Thing");
        readHashMapFromFile("category_labels", categoryLabels, "");
        categories.addAll(categoryLabels.keySet());
        System.out.println("Categories:");
        for (String c : categories) {
            System.out.println(c);
        }
        readHashMapFromFile("attribute_labels", attributeLabels, "");
        attributes.addAll(attributeLabels.keySet());
        System.out.println("Attributes:");
        for (String a : attributes) {
            System.out.println(a);
        }
    }

    private void readHashMapFromFile(String fileName, HashMap<String, HashSet<String>> hashmap, String defaultValue) throws Exception {
        System.out.println("Reading file " + destinationPath + fileName);
        try (BufferedReader in = new BufferedReader(new FileReader(destinationPath + fileName))) {
            String l = in.readLine();
            while (l != null) {
                if (l.length() > 0) {
                    StringTokenizer st = new StringTokenizer(l, "\t");
                    String c = st.nextToken();
                    String p = st.hasMoreTokens() ? st.nextToken() : defaultValue;
                    HashSet<String> ps = hashmap.get(c);
                    if (ps == null) {
                        ps = new HashSet<>();
                        hashmap.put(c, ps);
                    }
                    ps.add(p);
                }
                l = in.readLine();
            }
        }
    }

    public HashSet<String> processFiles() throws Exception {
        HashSet<String> res = new HashSet<>();
        System.out.println("Processing files");
        HashSet<String> ignoreAttributes = new HashSet<>();
        //ignoreAttributes.add("http://www.w3.org/2000/01/rdf-schema#seeAlso");
        //ignoreAttributes.add("http://www.w3.org/2000/01/rdf-schema#comment");
        //ignoreAttributes.add("http://www.w3.org/2002/07/owl#sameAs");
        //ignoreAttributes.add("http://xmlns.com/foaf/0.1/isPrimaryTopicOf");
        //ignoreAttributes.add("http://open.vocab.org/terms/sortLabel");
        //ignoreAttributes.add("http://www.w3.org/2004/02/skos/core#altLabel");
        //ignoreAttributes.add("http://purl.org/muto/core#taggedResource");
        //ignoreAttributes.add("http://purl.org/NET/c4dm/event.owl#factor");
        System.setErr(new PrintStream("/dev/null"));
        try (
                PrintWriter entityCategories = new PrintWriter(new FileOutputStream(destinationPath + "entity_categories", false), true);
                PrintWriter entityLabels = new PrintWriter(new FileOutputStream(destinationPath + "entity_labels", false), true);
                PrintWriter triples = new PrintWriter(new FileOutputStream(destinationPath + "triples", false), true)) {
            for (int k = files.length - 1; k >= 0; k--) {
                File f = files[k];
                if (!f.getCanonicalPath().endsWith(".nt")) {
                    continue;
                }
                System.out.println("Processing " + f.getCanonicalPath());

                NxParser nxp = new NxParser();
                nxp.parse(new FileInputStream(f));

                while (nxp.hasNext()) {
                    try {
                        Node[] ns = nxp.next();
                        if (ns.length == 3) {
                            String eUri;
                            if (ns[0] instanceof Resource) {
                                eUri = ((Resource) ns[0]).toURI().toString();
                            } else if (ns[0].toString().startsWith("_:node")) {
                                eUri = "http://musicbrainz.org/" + ns[0].getLabel();
                                entityLabels.println(eUri + "\t" + ns[0].getLabel());
                            } else {
                                System.out.println("Invalid pattern: subject is " + ns[0]);
                                continue;
                            }
                            if (ns[1] instanceof Resource) {
                                String aUri = ((Resource) ns[1]).toURI().toString();
                                if ("http://xmlns.com/foaf/0.1/name".equals(aUri) || "http://purl.org/dc/elements/1.1/title".equals(aUri) || "http://www.w3.org/2000/01/rdf-schema#label".equals(aUri)) {
                                    if (ns[2] instanceof Literal) {
                                        String l = eUri + "\t" + ((Literal) ns[2]).getLabel();
                                        StringTokenizer st = new StringTokenizer(l, "\t<>");
                                        try {
                                            st.nextToken();
                                            st.nextToken();
                                            entityLabels.println(l);
                                            triples.println(ns[0] + " " + ns[1] + " " + ns[2] + " .");
                                        } catch (Exception e) {
                                        }
                                    } else {
                                        System.out.println("Invalid name: " + ns[2]);
                                    }
                                } else if ("http://purl.org/muto/core#tagLabel".equals(aUri) || "http://www.w3.org/2004/02/skos/core#altLabel".equals(aUri)) {
                                    if (ns[2] instanceof Literal) {
                                        String l = eUri + "\t" + ((Literal) ns[2]).getLabel();
                                        StringTokenizer st = new StringTokenizer(l, "\t<>");
                                        try {
                                            st.nextToken();
                                            st.nextToken();
                                            entityLabels.println(l);
                                        } catch (Exception e) {
                                        }
                                    } else {
                                        System.out.println("Invalid label: " + ns[2]);
                                    }
                                } else if ("http://www.w3.org/1999/02/22-rdf-syntax-ns#type".equals(aUri)) {
                                    if (ns[2] instanceof Resource) {
                                        String vUri = ((Resource) ns[2]).toURI().toString();
                                        if (categories.contains(vUri)) {
                                            entityCategories.println(eUri + "\t" + vUri);
                                        } else {
                                            System.out.println("Unknown category: " + vUri);
                                        }
                                    } else {
                                        System.out.println("Invalid category: " + ns[2]);
                                    }
                                } else if (attributes.contains(aUri)) {
                                    String vUri;
                                    if (ns[2] instanceof Resource) {
                                        vUri = ((Resource) ns[2]).toURI().toString();
                                        triples.println("<" + eUri + "> <" + aUri + "> <" + vUri + "> .");
                                    } else if (ns[2].toString().startsWith("_:node")) {
                                        vUri = "http://musicbrainz.org/" + ns[2].getLabel();
                                        entityLabels.println(vUri + "\t" + ns[2].getLabel());
                                        triples.println("<" + eUri + "> <" + aUri + "> <" + vUri + "> .");
                                    } else if (ns[2] instanceof Literal) {
                                        triples.println("<" + eUri + "> <" + aUri + "> " + ns[2] + " .");
                                    } else {
                                        System.out.println("Invalid pattern: value is " + ns[2]);
                                        continue;
                                    }
                                } else if (!ignoreAttributes.contains(aUri)) {
                                    System.out.println("Unknown attribute: " + aUri);
                                }
                            } else {
                                System.out.println("Invalid pattern: attribute is " + ns[1]);
                            }

                        } else {
                            System.out.println("Invalid pattern: " + ns.length + " elements instead of 3");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return res;
    }

    public void createBasicTypesLiteralTypesFile() throws Exception {
        System.out.println("Saving basic types");
        try (PrintWriter out = new PrintWriter(new FileOutputStream(destinationPath + "basic_types_literal_types", false), true)) {
            out.println("http://www.w3.org/1999/02/22-rdf-syntax-ns#langString\tString");
            out.println("http://www.w3.org/2001/XMLSchema#gMonthDay\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#anyURI\tString");
            out.println("http://www.w3.org/2001/XMLSchema#boolean\tBoolean");
            out.println("http://www.w3.org/2001/XMLSchema#date\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#dateTime\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#double\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#float\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#gYear\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#gYearMonth\tDate");
            out.println("http://www.w3.org/2001/XMLSchema#integer\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#nonNegativeInteger\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#positiveInteger\tDouble");
            out.println("http://www.w3.org/2001/XMLSchema#string\tString");
            out.println("http://www.w3.org/2001/XMLSchema#decimal\tDouble");
            //out.println("http://musicbrainz.org/mm/mm-2.1#beginDate\tDate");
            //out.println("http://musicbrainz.org/mm/mm-2.1#endDate\tDate");
            //out.println("http://musicbrainz.org/mm/mm-2.1#duration\tDouble");

        }
    }

    public static void main(String... args) throws Exception {
        long start = System.currentTimeMillis();
        System.out.println("Started at " + new Date());
        MusicBrainzOldOntologyUtils musicbrainz = new MusicBrainzOldOntologyUtils("/home/massimo/aquawd/musicbrainz-old-downloaded-files/", "/home/massimo/aquawd/musicbrainz-old-ontology-files/");
        musicbrainz.processFiles();
        musicbrainz.createBasicTypesLiteralTypesFile();
        System.out.println("Ended at " + new Date());
        long time = System.currentTimeMillis() - start;
        long sec = time / 1000;
        System.out.println("The process took " + (sec / 60) + "'" + (sec % 60) + "." + (time % 1000) + "\"");
    }

}
